import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/auth/AuthContext';
import { ProtectedRoute, RoleRoute } from '@/auth/ProtectedRoute';
import LoginPage from '@/features/auth/LoginPage';
import RegisterPage from '@/features/auth/RegisterPage';
import ProfilePage from '@/features/applicant/ProfilePage';
import NotificationSearchPage from '@/features/applicant/NotificationSearchPage';
import NotificationDetailPage from '@/features/applicant/NotificationDetailPage';
import MyApplicationsPage from '@/features/applicant/MyApplicationsPage';
import ScorecardPage from '@/features/applicant/ScorecardPage';
import AdmitCardPage from '@/features/applicant/AdmitCardPage';
import NotificationBuilderPage from '@/features/admin/NotificationBuilderPage';
import ReviewQueuePage from '@/features/admin/ReviewQueuePage';
import ExamConsolePage from '@/features/admin/ExamConsolePage';
import MarksEntryPage from '@/features/admin/MarksEntryPage';
import ObjectionsPage from '@/features/admin/ObjectionsPage';
import SystemConfigPage from '@/features/admin/SystemConfigPage';
import UsersPage from '@/features/admin/UsersPage';
import ReportsPage from '@/features/admin/ReportsPage';
import AuditLogPage from '@/features/admin/AuditLogPage';

function Dashboard() {
  return <div className="p-5"><h1 className="text-2xl font-bold">Dashboard</h1>
    <p className="text-gray-600 mt-2">Welcome to the Government Job Portal.</p></div>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          <Route path="/notifications" element={<ProtectedRoute><NotificationSearchPage /></ProtectedRoute>} />
          <Route path="/notifications/:id" element={<ProtectedRoute><NotificationDetailPage /></ProtectedRoute>} />
          <Route path="/applications" element={<ProtectedRoute><MyApplicationsPage /></ProtectedRoute>} />
          <Route path="/applications/:applicationId/admit-card" element={<ProtectedRoute><AdmitCardPage /></ProtectedRoute>} />
          <Route path="/applications/:applicationId/scorecard" element={<ProtectedRoute><ScorecardPage /></ProtectedRoute>} />
          <Route path="/admin/notifications/new" element={<RoleRoute role="SYS_ADMIN"><NotificationBuilderPage /></RoleRoute>} />
          <Route path="/admin/review" element={<RoleRoute role="REVIEWER"><ReviewQueuePage /></RoleRoute>} />
          <Route path="/admin/exam/:notificationId" element={<RoleRoute role="EXAM_COORD"><ExamConsolePage /></RoleRoute>} />
          <Route path="/admin/results/:notificationId" element={<RoleRoute role="EXAM_COORD"><MarksEntryPage /></RoleRoute>} />
          <Route path="/admin/objections" element={<RoleRoute role="EXAM_COORD"><ObjectionsPage /></RoleRoute>} />
          <Route path="/admin/config" element={<RoleRoute role="SYS_ADMIN"><SystemConfigPage /></RoleRoute>} />
          <Route path="/admin/users" element={<RoleRoute role="SYS_ADMIN"><UsersPage /></RoleRoute>} />
          <Route path="/admin/reports" element={<RoleRoute role="SYS_ADMIN"><ReportsPage /></RoleRoute>} />
          <Route path="/admin/audit" element={<RoleRoute role="SYS_ADMIN"><AuditLogPage /></RoleRoute>} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
