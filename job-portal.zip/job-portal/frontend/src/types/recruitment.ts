export interface VacancyEntry { postName: string; totalSeats: number; reservation: Record<string, number>; eligibility: Record<string, unknown>; }
export interface NotificationRequest { title: string; department: string; description?: string; openDate: string; closeDate: string; vacancies: VacancyEntry[]; stages?: Record<string, unknown>[]; feeGeneral?: number; feeReserved?: number; }
export interface VacancyResponse { id: number; postName: string; totalSeats: number; reservation: Record<string, number>; eligibility: Record<string, unknown>; }
export interface NotificationResponse { id: number; title: string; department: string; description?: string; openDate: string; closeDate: string; feeGeneral?: number; feeReserved?: number; status: string; vacancies: VacancyResponse[]; }
export interface PageResponse<T> { content: T[]; totalElements: number; totalPages: number; number: number; size: number; }
