export interface Violation { code: string; message: string; }
export interface EligibilityCheckResponse { eligible: boolean; violations: Violation[]; }
export interface ApplicationResponse { id: number; vacancyId: number; postName: string; department: string; notificationTitle: string; status: string; reviewRemarks?: string; appliedAt: string; }
export interface PageResponse<T> { content: T[]; totalElements: number; totalPages: number; number: number; size: number; }
