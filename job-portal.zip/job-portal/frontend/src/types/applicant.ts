export interface EducationEntry { level: string; board?: string; year?: number; percentage?: number; }
export interface AddressEntry { line1: string; line2?: string; city: string; state: string; pincode: string; }
export interface ProfileRequest { fullName: string; dob: string; category?: string; gender?: string; education: EducationEntry[]; experience?: Record<string, unknown>[]; address: AddressEntry; }
export interface ProfileResponse extends ProfileRequest { id: number; otrCompleted: boolean; }
