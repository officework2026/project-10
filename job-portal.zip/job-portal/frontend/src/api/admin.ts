import apiClient from './client';
import type { PageResponse } from '@/types/application';

export interface ConfigItem { key: string; value: string; description?: string; }
export interface Template { id: number; code: string; subject: string; body: string; channel: string; updatedAt: string; }
export interface AdminUser { id: number; email: string; mobile: string; status: string; roles: string[]; createdAt: string; }

export async function listConfig(): Promise<ConfigItem[]> {
  const { data } = await apiClient.get('/admin/config');
  return data;
}
export async function updateConfig(key: string, value: string) {
  const { data } = await apiClient.put(`/admin/config/${key}`, null, { params: { value } });
  return data as ConfigItem;
}
export async function listTemplates(): Promise<Template[]> {
  const { data } = await apiClient.get('/admin/templates');
  return data;
}
export async function updateTemplate(id: number, subject: string, body: string) {
  const { data } = await apiClient.put(`/admin/templates/${id}`, null, { params: { subject, body } });
  return data as Template;
}
export async function listUsers(page = 0, size = 20): Promise<PageResponse<AdminUser>> {
  const { data } = await apiClient.get('/admin/users', { params: { page, size } });
  return data;
}
export async function createUser(payload: { email: string; mobile: string; password: string; roles: string[]; }): Promise<AdminUser> {
  const { data } = await apiClient.post('/admin/users', payload);
  return data;
}
export async function updateUserRoles(id: number, roles: string[]): Promise<AdminUser> {
  const { data } = await apiClient.patch(`/admin/users/${id}/roles`, roles);
  return data;
}
export async function downloadReport(type: 'by-category'|'by-gender'|'fee-collection'|'vacancy-fill', notificationId: number, format: 'csv'|'pdf' = 'csv'): Promise<Blob> {
  const { data } = await apiClient.get(`/admin/reports/${type}`, { params: { notificationId, format }, responseType: 'blob' });
  return data;
}
