import apiClient from './client';
import type { ProfileRequest, ProfileResponse } from '@/types/applicant';

export async function fetchProfile(): Promise<ProfileResponse | null> {
  const { data, status } = await apiClient.get('/applicant/profile', {
    validateStatus: (s) => s === 200 || s === 404,
  });
  return status === 200 ? data : null;
}

export async function saveProfile(payload: ProfileRequest): Promise<ProfileResponse> {
  const { data } = await apiClient.put('/applicant/profile', payload);
  return data;
}
