import apiClient from './client';
import type { PageResponse } from '@/types/application';

export interface ReviewItem { id: number; vacancyId: number; postName: string; notificationId: number; notificationTitle: string; department: string; status: string; reviewRemarks?: string; appliedAt: string; }

export async function fetchReviewQueue(params: { notificationId?: number; status?: string; page?: number; size?: number; }): Promise<PageResponse<ReviewItem>> {
  const { data } = await apiClient.get('/admin/review', { params });
  return data;
}
export async function approveApplication(id: number, remarks?: string): Promise<ReviewItem> {
  const { data } = await apiClient.patch(`/admin/review/${id}/approve`, { remarks });
  return data;
}
export async function rejectApplication(id: number, remarks?: string): Promise<ReviewItem> {
  const { data } = await apiClient.patch(`/admin/review/${id}/reject`, { remarks });
  return data;
}
export async function batchReview(applicationIds: number[], targetStatus: 'ELIGIBLE'|'REJECTED', remarks?: string): Promise<ReviewItem[]> {
  const { data } = await apiClient.post('/admin/review/batch', { applicationIds, targetStatus, remarks });
  return data;
}
