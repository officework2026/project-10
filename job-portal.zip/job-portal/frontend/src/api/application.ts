import apiClient from './client';
import type { ApplicationResponse, EligibilityCheckResponse, PageResponse } from '@/types/application';

export async function checkEligibility(vacancyId: number): Promise<EligibilityCheckResponse> {
  const { data } = await apiClient.get(`/applications/eligibility/${vacancyId}`);
  return data;
}
export async function applyForVacancy(vacancyId: number, declarationAccepted: boolean): Promise<ApplicationResponse> {
  const { data } = await apiClient.post('/applications', { vacancyId, declarationAccepted });
  return data;
}
export async function fetchMyApplications(page = 0, size = 20): Promise<PageResponse<ApplicationResponse>> {
  const { data } = await apiClient.get('/applications', { params: { page, size } });
  return data;
}
