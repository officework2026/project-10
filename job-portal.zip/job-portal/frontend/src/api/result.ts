import apiClient from './client';
import type { PageResponse } from '@/types/application';

export interface ResultResponse { id: number; applicationId: number; postName: string; notificationTitle: string; marks: Record<string, number>; total: number; qualified: boolean; publishedAt?: string; hasObjection: boolean; objectionStatus?: string; }
export interface ObjectionResponse { id: number; resultId: number; questionRef: string; justification: string; status: string; adminRemarks?: string; raisedAt: string; resolvedAt?: string; }

export async function getMyResult(applicationId: number) {
  const { data } = await apiClient.get(`/applications/${applicationId}/result`);
  return data as ResultResponse;
}
export async function raiseObjection(applicationId: number, payload: { questionRef: string; justification: string; }) {
  const { data } = await apiClient.post(`/applications/${applicationId}/objections`, payload);
  return data as ObjectionResponse;
}
export async function listMyObjections(applicationId: number, page = 0, size = 20) {
  const { data } = await apiClient.get(`/applications/${applicationId}/objections`, { params: { page, size } });
  return data as PageResponse<ObjectionResponse>;
}
export async function enterMarks(applicationId: number, payload: { marks: Record<string, number>; total: number; qualified: boolean; }) {
  const { data } = await apiClient.post(`/admin/results/applications/${applicationId}/marks`, payload);
  return data as ResultResponse;
}
export async function publishResult(resultId: number) {
  const { data } = await apiClient.post(`/admin/results/${resultId}/publish`);
  return data as ResultResponse;
}
export async function publishAllResults(notificationId: number) {
  const { data } = await apiClient.post(`/admin/results/notifications/${notificationId}/publish-all`);
  return data as number;
}
export async function listResults(notificationId: number, page = 0, size = 20) {
  const { data } = await apiClient.get('/admin/results', { params: { notificationId, page, size } });
  return data as PageResponse<ResultResponse>;
}
export async function listObjections(status = 'SUBMITTED', page = 0, size = 20) {
  const { data } = await apiClient.get('/admin/results/objections', { params: { status, page, size } });
  return data as PageResponse<ObjectionResponse>;
}
export async function resolveObjection(id: number, status: 'ACCEPTED'|'REJECTED', remarks?: string) {
  const { data } = await apiClient.patch(`/admin/results/objections/${id}`, null, { params: { status, remarks } });
  return data as ObjectionResponse;
}
