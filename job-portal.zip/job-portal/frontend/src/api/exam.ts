import apiClient from './client';

export interface CenterRequest { name: string; city: string; capacity: number; }
export interface CenterResponse { id: number; notificationId: number; name: string; city: string; capacity: number; allocatedCount: number; remaining: number; }
export interface AllocationResult { totalEligible: number; allocated: number; unallocated: number; warnings: string[]; }
export interface BatchJobStatus { jobId: string; state: 'PENDING'|'RUNNING'|'COMPLETED'|'FAILED'; processed: number; total: number; startedAt: string; completedAt?: string; errorMessage?: string; }
export interface AdmitCardResponse { id: number; applicationId: number; rollNumber: string; centerName: string; centerCity: string; examDate: string; qrPayload: string; pdfReady: boolean; }

export async function createCenter(notificationId: number, payload: CenterRequest) {
  const { data } = await apiClient.post(`/admin/exam/notifications/${notificationId}/centers`, payload);
  return data as CenterResponse;
}
export async function listCenters(notificationId: number) {
  const { data } = await apiClient.get(`/admin/exam/notifications/${notificationId}/centers`);
  return data as CenterResponse[];
}
export async function runAllocation(notificationId: number) {
  const { data } = await apiClient.post(`/admin/exam/notifications/${notificationId}/allocate`);
  return data as AllocationResult;
}
export async function startAdmitCardBatch(notificationId: number) {
  const { data } = await apiClient.post(`/admin/exam/notifications/${notificationId}/admit-cards/generate`, null, { validateStatus: (s) => s === 202 });
  return data as { jobId: string };
}
export async function getJobStatus(jobId: string) {
  const { data } = await apiClient.get(`/admin/exam/jobs/${jobId}`);
  return data as BatchJobStatus;
}
export async function getMyAdmitCard(applicationId: number) {
  const { data, status } = await apiClient.get(`/applications/${applicationId}/admit-card`, {
    validateStatus: (s) => s === 200 || s === 404,
  });
  return status === 200 ? (data as AdmitCardResponse) : null;
}
