import axios from 'axios';
import { getToken, clearToken } from '@/auth/tokenStore';

const apiClient = axios.create({
  baseURL: '/api/v1',
  headers: { 'Content-Type': 'application/json' },
});

apiClient.interceptors.request.use((config) => {
  const t = getToken();
  if (t) config.headers.Authorization = `Bearer ${t}`;
  return config;
});

apiClient.interceptors.response.use(
  (r) => r,
  (e) => {
    if (e.response?.status === 401 && !e.config.url?.includes('/auth/')) {
      clearToken();
      window.location.href = '/login';
    }
    return Promise.reject(e);
  }
);

export default apiClient;
