import apiClient from './client';
export async function presignUpload(applicationId: number, documentType: string) {
  const { data } = await apiClient.post(`/applications/${applicationId}/documents/presign`, null, { params: { documentType } });
  return data as { uploadUrl: string; objectKey: string };
}
export async function confirmUpload(applicationId: number, payload: { documentType: string; objectKey: string; originalName: string; contentType: string; fileSize: number; }) {
  const { data } = await apiClient.post(`/applications/${applicationId}/documents/confirm`, null, { params: payload });
  return data;
}
