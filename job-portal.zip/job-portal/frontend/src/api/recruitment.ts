import apiClient from './client';
import type { NotificationRequest, NotificationResponse, PageResponse } from '@/types/recruitment';

export async function searchNotifications(params: { department?: string; keyword?: string; closingAfter?: string; page?: number; size?: number; }): Promise<PageResponse<NotificationResponse>> {
  const { data } = await apiClient.get('/notifications', { params });
  return data;
}
export async function getNotification(id: number): Promise<NotificationResponse> {
  const { data } = await apiClient.get(`/notifications/${id}`);
  return data;
}
export async function createDraft(payload: NotificationRequest): Promise<NotificationResponse> {
  const { data } = await apiClient.post('/admin/notifications', payload);
  return data;
}
export async function publishNotification(id: number): Promise<NotificationResponse> {
  const { data } = await apiClient.post(`/admin/notifications/${id}/publish`);
  return data;
}
