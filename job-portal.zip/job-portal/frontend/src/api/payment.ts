import apiClient from './client';
export interface PaymentTransaction { id: number; gatewayRef: string; status: string; amount: number; }
export async function initiatePayment(applicationId: number, amount: number) {
  const { data } = await apiClient.post(`/payments/initiate/${applicationId}`, null, { params: { amount } });
  return data as PaymentTransaction;
}
export async function getPaymentByApplication(applicationId: number) {
  const { data } = await apiClient.get(`/payments/application/${applicationId}`);
  return data as PaymentTransaction;
}
