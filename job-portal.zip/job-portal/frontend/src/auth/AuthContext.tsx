import { createContext, useContext, useState, ReactNode } from 'react';
import { jwtDecode } from 'jwt-decode';
import { setToken, clearToken, getToken } from './tokenStore';
import apiClient from '@/api/client';

interface AuthUser { email: string; roles: string[]; }
interface AuthContextType {
  user: AuthUser | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}
const AuthContext = createContext<AuthContextType | null>(null);

function decodeUser(token: string): AuthUser {
  const p = jwtDecode<{ sub: string; authorities: string[] }>(token);
  return { email: p.sub, roles: p.authorities.map((a) => a.replace('ROLE_', '')) };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => {
    const t = getToken();
    return t ? decodeUser(t) : null;
  });

  async function login(email: string, password: string) {
    const { data } = await apiClient.post('/auth/login', { email, password });
    setToken(data.accessToken);
    setUser(decodeUser(data.accessToken));
  }

  function logout() { clearToken(); setUser(null); }

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const c = useContext(AuthContext);
  if (!c) throw new Error('useAuth must be inside AuthProvider');
  return c;
}
