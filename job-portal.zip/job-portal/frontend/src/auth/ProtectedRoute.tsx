import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { ReactNode } from 'react';

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
}

export function RoleRoute({ children, role }: { children: ReactNode; role: string }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return user.roles.includes(role) ? <>{children}</> : <Navigate to="/dashboard" replace />;
}
