import { useEffect, useState } from 'react';
import { Message } from 'primereact/message';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { Checkbox } from 'primereact/checkbox';
import { Dialog } from 'primereact/dialog';
import { Toast } from 'primereact/toast';
import { useRef } from 'react';
import { checkEligibility, applyForVacancy } from '@/api/application';
import type { EligibilityCheckResponse } from '@/types/application';

export default function EligibilityPanel({ vacancyId, postName, onApplied }: {
  vacancyId: number; postName: string; onApplied?: () => void;
}) {
  const [res, setRes] = useState<EligibilityCheckResponse | null>(null);
  const [visible, setVisible] = useState(false);
  const [decl, setDecl] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const toast = useRef<Toast>(null);

  useEffect(() => { checkEligibility(vacancyId).then(setRes); }, [vacancyId]);

  async function submit() {
    setSubmitting(true);
    try {
      await applyForVacancy(vacancyId, decl);
      toast.current?.show({ severity: 'success', summary: 'Applied', detail: `Applied for ${postName}` });
      setVisible(false); onApplied?.();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    } finally { setSubmitting(false); }
  }

  if (!res) return <small>Checking...</small>;
  return (
    <div>
      <Toast ref={toast} />
      {res.eligible
        ? <Message severity="success" text="Eligible" className="w-full mb-2" />
        : <div className="mb-2">{res.violations.map((v) => (
            <div key={v.code}><Tag value={v.code} severity="danger" /> <small>{v.message}</small></div>
          ))}</div>}
      <Button label="Apply Now" icon="pi pi-send" disabled={!res.eligible} onClick={() => setVisible(true)} />
      <Dialog header={`Apply: ${postName}`} visible={visible} onHide={() => setVisible(false)} style={{ width: '450px' }}
        footer={<div className="flex justify-content-end gap-2">
          <Button label="Cancel" text severity="secondary" onClick={() => setVisible(false)} />
          <Button label="Submit" icon="pi pi-check" disabled={!decl} loading={submitting} onClick={submit} />
        </div>}>
        <div className="flex align-items-start gap-2">
          <Checkbox inputId="decl" checked={decl} onChange={(e) => setDecl(!!e.checked)} />
          <label htmlFor="decl">I declare all information is true.</label>
        </div>
      </Dialog>
    </div>
  );
}
