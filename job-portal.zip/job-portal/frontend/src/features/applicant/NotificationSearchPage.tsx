import { useEffect, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { useNavigate } from 'react-router-dom';
import { searchNotifications } from '@/api/recruitment';
import type { NotificationResponse } from '@/types/recruitment';

export default function NotificationSearchPage() {
  const [items, setItems] = useState<NotificationResponse[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [state, setState] = useState({ first: 0, rows: 20 });
  const [kw, setKw] = useState('');
  const nav = useNavigate();

  useEffect(() => {
    setLoading(true);
    searchNotifications({ keyword: kw || undefined, page: Math.floor(state.first / state.rows), size: state.rows })
      .then((d) => { setItems(d.content); setTotal(d.totalElements); })
      .finally(() => setLoading(false));
  }, [state, kw]);

  return (
    <div className="p-5">
      <h2 className="mb-4">Government Job Notifications</h2>
      <InputText value={kw} onChange={(e) => setKw(e.target.value)} placeholder="Search title..." className="w-full md:w-20rem mb-3" />
      <DataTable value={items} lazy paginator loading={loading} totalRecords={total}
        first={state.first} rows={state.rows}
        onPage={(e) => setState({ first: e.first, rows: e.rows })}
        emptyMessage="No notifications">
        <Column field="title" header="Title" />
        <Column field="department" header="Department" />
        <Column field="openDate" header="Open" />
        <Column field="closeDate" header="Close" />
        <Column field="status" header="Status" body={(r) => (
          <Tag value={r.status} severity={r.status === 'PUBLISHED' ? 'success' : 'warning'} />)} />
        <Column header="Action" body={(r) => (
          <Button label="View" icon="pi pi-eye" text onClick={() => nav(`/notifications/${r.id}`)} />)} />
      </DataTable>
    </div>
  );
}
