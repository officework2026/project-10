import { useEffect, useState } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Message } from 'primereact/message';
import { fetchProfile, saveProfile } from '@/api/applicant';

const educationSchema = z.object({ level: z.string().min(1), board: z.string().optional(), year: z.number().optional(), percentage: z.number().optional() });
const schema = z.object({
  fullName: z.string().min(1).max(150),
  dob: z.date({ required_error: 'Required' }),
  category: z.enum(['GEN','OBC','SC','ST','EWS']).optional(),
  gender: z.enum(['MALE','FEMALE','OTHER']).optional(),
  education: z.array(educationSchema).min(1),
  address: z.object({
    line1: z.string().min(1), line2: z.string().optional(),
    city: z.string().min(1), state: z.string().min(1),
    pincode: z.string().regex(/^[1-9][0-9]{5}$/),
  }),
});
type FormData = z.infer<typeof schema>;

export default function ProfilePage() {
  const [loading, setLoading] = useState(true);
  const [otr, setOtr] = useState(false);
  const { control, handleSubmit, reset, formState: { isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { fullName: '', education: [{ level: '' }], address: { line1: '', city: '', state: '', pincode: '' } },
  });
  const { fields, append, remove } = useFieldArray({ control, name: 'education' });

  useEffect(() => {
    fetchProfile().then((p) => {
      if (p) reset({
        fullName: p.fullName, dob: new Date(p.dob),
        category: p.category as any, gender: p.gender as any,
        education: (p.education as any) ?? [{ level: '' }],
        address: p.address as any,
      });
      setOtr(p?.otrCompleted ?? false);
    }).finally(() => setLoading(false));
  }, [reset]);

  async function onSubmit(data: FormData) {
    const payload = { ...data, dob: data.dob.toISOString().split('T')[0] };
    const r = await saveProfile(payload as any);
    setOtr(r.otrCompleted);
  }

  if (loading) return <div className="p-5">Loading...</div>;

  return (
    <div className="p-5 max-w-4xl mx-auto">
      <div className="flex align-items-center justify-content-between mb-4">
        <h2>Applicant Profile (OTR)</h2>
        {otr && <Message severity="success" text="OTR Completed" />}
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-column gap-3">
        <div>
          <label className="block mb-1 font-medium">Full Name *</label>
          <Controller name="fullName" control={control} render={({ field }) => <InputText {...field} className="w-full" />} />
        </div>
        <div>
          <label className="block mb-1 font-medium">DOB *</label>
          <Controller name="dob" control={control} render={({ field }) => (
            <Calendar value={field.value} onChange={(e) => field.onChange(e.value)} showIcon maxDate={new Date()} className="w-full" />)} />
        </div>
        <div className="grid">
          <div className="col-6">
            <label className="block mb-1">Category</label>
            <Controller name="category" control={control} render={({ field }) => (
              <Dropdown value={field.value} onChange={(e) => field.onChange(e.value)}
                options={[{label:'GEN',value:'GEN'},{label:'OBC',value:'OBC'},{label:'SC',value:'SC'},{label:'ST',value:'ST'},{label:'EWS',value:'EWS'}]}
                className="w-full" />)} />
          </div>
          <div className="col-6">
            <label className="block mb-1">Gender</label>
            <Controller name="gender" control={control} render={({ field }) => (
              <Dropdown value={field.value} onChange={(e) => field.onChange(e.value)}
                options={[{label:'Male',value:'MALE'},{label:'Female',value:'FEMALE'},{label:'Other',value:'OTHER'}]}
                className="w-full" />)} />
          </div>
        </div>
        <h3 className="mt-3">Education</h3>
        {fields.map((f, i) => (
          <div key={f.id} className="surface-card p-3 border-round">
            <div className="flex justify-content-between mb-2">
              <span>Qualification {i+1}</span>
              {fields.length > 1 && <Button type="button" icon="pi pi-trash" severity="danger" text onClick={() => remove(i)} />}
            </div>
            <div className="grid">
              <div className="col-6">
                <Controller name={`education.${i}.level`} control={control} render={({ field }) => (
                  <InputText {...field} placeholder="Level (GRADUATION)" className="w-full" />)} />
              </div>
              <div className="col-6">
                <Controller name={`education.${i}.board`} control={control} render={({ field }) => (
                  <InputText {...field} placeholder="Board/University" className="w-full" />)} />
              </div>
            </div>
          </div>
        ))}
        <Button type="button" label="Add Qualification" icon="pi pi-plus" text onClick={() => append({ level: '' })} />
        <h3 className="mt-3">Address</h3>
        <Controller name="address.line1" control={control} render={({ field }) => (
          <InputText {...field} placeholder="Address line 1" className="w-full" />)} />
        <Controller name="address.line2" control={control} render={({ field }) => (
          <InputText {...field} placeholder="Address line 2" className="w-full" />)} />
        <div className="grid">
          <div className="col-4">
            <Controller name="address.city" control={control} render={({ field }) => (
              <InputText {...field} placeholder="City" className="w-full" />)} />
          </div>
          <div className="col-4">
            <Controller name="address.state" control={control} render={({ field }) => (
              <InputText {...field} placeholder="State" className="w-full" />)} />
          </div>
          <div className="col-4">
            <Controller name="address.pincode" control={control} render={({ field }) => (
              <InputText {...field} placeholder="Pincode" maxLength={6} className="w-full" />)} />
          </div>
        </div>
        <Button type="submit" label="Save Profile" icon="pi pi-check" loading={isSubmitting} />
      </form>
    </div>
  );
}
