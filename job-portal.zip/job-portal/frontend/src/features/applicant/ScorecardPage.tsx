import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Card } from 'primereact/card';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Message } from 'primereact/message';
import { Toast } from 'primereact/toast';
import { useRef } from 'react';
import { getMyResult, raiseObjection, listMyObjections } from '@/api/result';

export default function ScorecardPage() {
  const { applicationId } = useParams();
  const [result, setResult] = useState<any>(null);
  const [objections, setObjections] = useState<any[]>([]);
  const [visible, setVisible] = useState(false);
  const [qref, setQref] = useState('');
  const [just, setJust] = useState('');
  const toast = useRef<Toast>(null);

  function load() {
    if (!applicationId) return;
    getMyResult(Number(applicationId)).then(setResult).catch(() => setResult(null));
    listMyObjections(Number(applicationId)).then((p) => setObjections(p.content));
  }
  useEffect(load, [applicationId]);

  async function submitObj() {
    try {
      await raiseObjection(Number(applicationId), { questionRef: qref, justification: just });
      toast.current?.show({ severity: 'success', summary: 'Objection raised' });
      setVisible(false); setQref(''); setJust(''); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Failed', detail: e.response?.data?.message });
    }
  }

  if (!result) return <div className="p-5"><Message severity="info" text="Result not published" /></div>;

  return (
    <div className="p-5 max-w-4xl mx-auto">
      <Toast ref={toast} />
      <Card title="Scorecard" subTitle={result.notificationTitle}>
        <div className="flex gap-3 mb-3">
          <Tag value={result.qualified ? 'QUALIFIED' : 'NOT QUALIFIED'}
            severity={result.qualified ? 'success' : 'danger'} />
          <Tag value={`Total: ${result.total}`} severity="info" />
        </div>
        <h4>Marks</h4>
        <ul>{Object.entries(result.marks).map(([k, v]) => (
          <li key={k}><b>{k}:</b> {v as number}</li>))}</ul>
        <h4>Objections</h4>
        {objections.length === 0 && <p>None.</p>}
        {objections.map((o) => (
          <div key={o.id} className="surface-card p-2 border-round mb-2">
            <p><b>{o.questionRef}:</b> {o.justification}</p>
            <Tag value={o.status} severity={o.status === 'ACCEPTED' ? 'success' : o.status === 'REJECTED' ? 'danger' : 'warning'} />
            {o.adminRemarks && <small className="block mt-1">Remarks: {o.adminRemarks}</small>}
          </div>
        ))}
        <Button label="Raise Objection" icon="pi pi-flag" severity="warning" onClick={() => setVisible(true)} />
      </Card>
      <Dialog header="Raise Objection" visible={visible} onHide={() => setVisible(false)} style={{ width: '450px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setVisible(false)} />
          <Button label="Submit" icon="pi pi-check" onClick={submitObj} />
        </div>}>
        <div className="flex flex-column gap-3">
          <InputText value={qref} onChange={(e) => setQref(e.target.value)} placeholder="Question (e.g. Q12)" />
          <InputTextarea rows={4} value={just} onChange={(e) => setJust(e.target.value)} placeholder="Justification" />
        </div>
      </Dialog>
    </div>
  );
}
