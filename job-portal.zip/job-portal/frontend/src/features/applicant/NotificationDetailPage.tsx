import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Card } from 'primereact/card';
import { Tag } from 'primereact/tag';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { getNotification } from '@/api/recruitment';
import type { NotificationResponse } from '@/types/recruitment';
import EligibilityPanel from './EligibilityPanel';

export default function NotificationDetailPage() {
  const { id } = useParams();
  const [n, setN] = useState<NotificationResponse | null>(null);
  useEffect(() => { if (id) getNotification(Number(id)).then(setN); }, [id]);
  if (!n) return <div className="p-5">Loading...</div>;

  return (
    <div className="p-5 max-w-5xl mx-auto">
      <Card title={n.title} subTitle={n.department}>
        <p>{n.description}</p>
        <div className="flex gap-3 mb-3">
          <Tag value={`Open: ${n.openDate}`} severity="info" />
          <Tag value={`Close: ${n.closeDate}`} severity="warning" />
          <Tag value={n.status} severity="success" />
        </div>
      </Card>
      <h3 className="mt-4">Vacancies</h3>
      <DataTable value={n.vacancies}>
        <Column field="postName" header="Post" />
        <Column field="totalSeats" header="Seats" />
        <Column header="Reservation" body={(r) => Object.entries(r.reservation).map(([k, v]) => `${k}:${v}`).join(' | ')} />
        <Column header="Action" body={(r) => <EligibilityPanel vacancyId={r.id} postName={r.postName} />} />
      </DataTable>
    </div>
  );
}
