import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Card } from 'primereact/card';
import { Message } from 'primereact/message';
import { getMyAdmitCard, type AdmitCardResponse } from '@/api/exam';
import QRCode from 'qrcode';

export default function AdmitCardPage() {
  const { applicationId } = useParams();
  const [card, setCard] = useState<AdmitCardResponse | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!applicationId) return;
    getMyAdmitCard(Number(applicationId))
      .then(async (c) => {
        setCard(c);
        if (c) setQr(await QRCode.toDataURL(c.qrPayload));
      }).finally(() => setLoading(false));
  }, [applicationId]);

  if (loading) return <div className="p-5">Loading...</div>;
  if (!card) return <div className="p-5"><Message severity="info" text="Admit card not yet generated." /></div>;

  return (
    <div className="p-5 max-w-3xl mx-auto">
      <Card title="Admit Card" subTitle={`Roll: ${card.rollNumber}`}>
        <div className="grid">
          <div className="col-8">
            <p><b>Center:</b> {card.centerName}, {card.centerCity}</p>
            <p><b>Exam Date:</b> {card.examDate}</p>
            <p><b>PDF Ready:</b> {card.pdfReady ? 'Yes' : 'Generating...'}</p>
          </div>
          <div className="col-4 flex justify-content-center">
            {qr && <img src={qr} alt="QR" style={{ width: 150 }} />}
          </div>
        </div>
      </Card>
    </div>
  );
}
