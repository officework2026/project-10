import { useEffect, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { useNavigate } from 'react-router-dom';
import { fetchMyApplications } from '@/api/application';
import type { ApplicationResponse } from '@/types/application';

const sev: Record<string, 'info'|'warning'|'success'|'danger'> = {
  SUBMITTED: 'info', UNDER_REVIEW: 'warning', ELIGIBLE: 'success', REJECTED: 'danger',
  ELIGIBLE_PENDING_REVIEW: 'warning', RESULT_PUBLISHED: 'success',
};

export default function MyApplicationsPage() {
  const [rows, setRows] = useState<ApplicationResponse[]>([]);
  const [total, setTotal] = useState(0);
  const [state, setState] = useState({ first: 0, rows: 20 });
  const [loading, setLoading] = useState(true);
  const nav = useNavigate();

  useEffect(() => {
    setLoading(true);
    fetchMyApplications(Math.floor(state.first / state.rows), state.rows)
      .then((d) => { setRows(d.content); setTotal(d.totalElements); })
      .finally(() => setLoading(false));
  }, [state]);

  return (
    <div className="p-5">
      <h2 className="mb-4">My Applications</h2>
      <DataTable value={rows} lazy paginator loading={loading} totalRecords={total}
        first={state.first} rows={state.rows}
        onPage={(e) => setState({ first: e.first, rows: e.rows })}
        emptyMessage="No applications yet">
        <Column field="notificationTitle" header="Notification" />
        <Column field="department" header="Department" />
        <Column field="postName" header="Post" />
        <Column field="status" header="Status" body={(r) => (
          <Tag value={r.status.replace(/_/g, ' ')} severity={sev[r.status] ?? 'info'} />)} />
        <Column header="Actions" body={(r) => (
          <div className="flex gap-1">
            <Button label="Scorecard" text icon="pi pi-file" onClick={() => nav(`/applications/${r.id}/scorecard`)} />
            <Button label="Admit Card" text icon="pi pi-id-card" onClick={() => nav(`/applications/${r.id}/admit-card`)} />
          </div>
        )} />
      </DataTable>
    </div>
  );
}
