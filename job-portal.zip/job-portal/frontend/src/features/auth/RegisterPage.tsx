import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { Button } from 'primereact/button';
import { Message } from 'primereact/message';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import apiClient from '@/api/client';

const schema = z.object({
  email: z.string().email(),
  mobile: z.string().regex(/^[6-9]\d{9}$/, 'Invalid Indian mobile'),
  password: z.string().min(8, 'Min 8 characters'),
});
type FormData = z.infer<typeof schema>;

export default function RegisterPage() {
  const nav = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const { control, handleSubmit, formState: { isSubmitting } } = useForm<FormData>({ resolver: zodResolver(schema) });

  async function onSubmit(data: FormData) {
    setError(null);
    try { await apiClient.post('/auth/register', data); setDone(true); setTimeout(() => nav('/login'), 1500); }
    catch (e: any) { setError(e.response?.data?.message ?? 'Registration failed'); }
  }

  if (done) return <div className="p-5"><Message severity="success" text="Registered. Redirecting to login..." /></div>;

  return (
    <div className="flex align-items-center justify-content-center min-h-screen bg-gray-50">
      <div className="surface-card p-5 border-round shadow-2 w-full max-w-30rem">
        <h2 className="text-center mb-4">Register</h2>
        {error && <Message severity="error" text={error} className="w-full mb-3" />}
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-column gap-3">
          <Controller name="email" control={control} render={({ field }) => (
            <InputText {...field} placeholder="Email" className="w-full" />)} />
          <Controller name="mobile" control={control} render={({ field }) => (
            <InputText {...field} placeholder="Mobile (10 digits)" className="w-full" />)} />
          <Controller name="password" control={control} render={({ field }) => (
            <Password value={field.value} onChange={(e) => field.onChange(e.target.value)}
              toggleMask feedback={false} className="w-full" inputClassName="w-full" />)} />
          <Button type="submit" label="Register" icon="pi pi-user-plus" loading={isSubmitting} className="w-full" />
        </form>
      </div>
    </div>
  );
}
