import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { Button } from 'primereact/button';
import { Message } from 'primereact/message';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/auth/AuthContext';

const schema = z.object({ email: z.string().email('Invalid email'), password: z.string().min(1, 'Password required') });
type FormData = z.infer<typeof schema>;

export default function LoginPage() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const { control, handleSubmit, formState: { isSubmitting } } = useForm<FormData>({ resolver: zodResolver(schema) });

  async function onSubmit(data: FormData) {
    setError(null);
    try { await login(data.email, data.password); nav('/dashboard'); }
    catch (e: any) { setError(e.response?.data?.message ?? 'Login failed'); }
  }

  return (
    <div className="flex align-items-center justify-content-center min-h-screen bg-gray-50">
      <div className="surface-card p-5 border-round shadow-2 w-full max-w-30rem">
        <h2 className="text-center mb-4">Government Job Portal</h2>
        {error && <Message severity="error" text={error} className="w-full mb-3" />}
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-column gap-3">
          <div>
            <label className="block mb-1 font-medium">Email</label>
            <Controller name="email" control={control} render={({ field, fieldState }) => (
              <>
                <InputText {...field} className={fieldState.invalid ? 'p-invalid w-full' : 'w-full'} />
                {fieldState.error && <small className="p-error">{fieldState.error.message}</small>}
              </>
            )} />
          </div>
          <div>
            <label className="block mb-1 font-medium">Password</label>
            <Controller name="password" control={control} render={({ field, fieldState }) => (
              <>
                <Password value={field.value} onChange={(e) => field.onChange(e.target.value)}
                  toggleMask feedback={false} className="w-full" inputClassName="w-full" />
                {fieldState.error && <small className="p-error">{fieldState.error.message}</small>}
              </>
            )} />
          </div>
          <Button type="submit" label="Sign In" icon="pi pi-sign-in" loading={isSubmitting} className="w-full" />
        </form>
        <p className="text-center mt-4 text-sm text-gray-600">
          New? <a href="/register" className="text-primary font-medium">Register</a>
        </p>
      </div>
    </div>
  );
}
