import { useState, useRef } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { InputNumber } from 'primereact/inputnumber';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { createDraft, publishNotification } from '@/api/recruitment';
import { useNavigate } from 'react-router-dom';

const vs = z.object({
  postName: z.string().min(1), totalSeats: z.number().min(1),
  gen: z.number().min(0).default(0), obc: z.number().min(0).default(0),
  sc: z.number().min(0).default(0), st: z.number().min(0).default(0),
  ews: z.number().min(0).default(0),
  minAge: z.number().min(18).max(60).default(18),
  maxAge: z.number().min(18).max(60).default(35),
  qualification: z.string().default('GRADUATION'),
});
const schema = z.object({
  title: z.string().min(1), department: z.string().min(1),
  description: z.string().optional(),
  openDate: z.date({ required_error: 'Required' }),
  closeDate: z.date({ required_error: 'Required' }),
  vacancies: z.array(vs).min(1),
  feeGeneral: z.number().optional(), feeReserved: z.number().optional(),
});
type FormData = z.infer<typeof schema>;
const defaults = { postName: '', totalSeats: 1, gen: 1, obc: 0, sc: 0, st: 0, ews: 0, minAge: 18, maxAge: 35, qualification: 'GRADUATION' };

export default function NotificationBuilderPage() {
  const toast = useRef<Toast>(null);
  const nav = useNavigate();
  const [draftId, setDraftId] = useState<number | null>(null);
  const { control, handleSubmit, formState: { isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { title: '', department: '', vacancies: [defaults] },
  });
  const { fields, append, remove } = useFieldArray({ control, name: 'vacancies' });

  function toPayload(d: FormData) {
    return {
      ...d,
      openDate: d.openDate.toISOString().split('T')[0],
      closeDate: d.closeDate.toISOString().split('T')[0],
      vacancies: d.vacancies.map((v) => ({
        postName: v.postName, totalSeats: v.totalSeats,
        reservation: { GEN: v.gen, OBC: v.obc, SC: v.sc, ST: v.st, EWS: v.ews },
        eligibility: { minAge: v.minAge, maxAge: v.maxAge, qualification: v.qualification },
      })),
    };
  }

  async function save(d: FormData) {
    try {
      const r = await createDraft(toPayload(d) as any);
      setDraftId(r.id);
      toast.current?.show({ severity: 'success', summary: 'Draft saved', detail: `ID: ${r.id}` });
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  async function publish() {
    if (!draftId) return;
    try {
      await publishNotification(draftId);
      toast.current?.show({ severity: 'success', summary: 'Published' });
      setTimeout(() => nav('/notifications'), 1000);
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  return (
    <div className="p-5 max-w-5xl mx-auto">
      <Toast ref={toast} />
      <div className="flex justify-content-between align-items-center mb-4">
        <h2>Create Notification</h2>
        {draftId && <Button label="Publish" icon="pi pi-send" severity="success" onClick={publish} />}
      </div>
      <form className="flex flex-column gap-3">
        <Controller name="title" control={control} render={({ field }) => <InputText {...field} placeholder="Title" className="w-full" />} />
        <Controller name="department" control={control} render={({ field }) => <InputText {...field} placeholder="Department" className="w-full" />} />
        <Controller name="description" control={control} render={({ field }) => <InputTextarea {...field} rows={3} placeholder="Description" className="w-full" />} />
        <div className="grid">
          <div className="col-4">
            <Controller name="openDate" control={control} render={({ field }) => (
              <Calendar value={field.value} onChange={(e) => field.onChange(e.value)} showIcon placeholder="Open Date" className="w-full" />)} />
          </div>
          <div className="col-4">
            <Controller name="closeDate" control={control} render={({ field }) => (
              <Calendar value={field.value} onChange={(e) => field.onChange(e.value)} showIcon placeholder="Close Date" className="w-full" />)} />
          </div>
          <div className="col-2">
            <Controller name="feeGeneral" control={control} render={({ field }) => (
              <InputNumber value={field.value} onValueChange={(e) => field.onChange(e.value)} placeholder="Fee General" className="w-full" />)} />
          </div>
          <div className="col-2">
            <Controller name="feeReserved" control={control} render={({ field }) => (
              <InputNumber value={field.value} onValueChange={(e) => field.onChange(e.value)} placeholder="Fee Reserved" className="w-full" />)} />
          </div>
        </div>
        <h3 className="mt-3">Vacancies</h3>
        {fields.map((f, i) => (
          <div key={f.id} className="surface-card p-3 border-round">
            <div className="flex justify-content-between mb-2">
              <span>Vacancy {i+1}</span>
              {fields.length > 1 && <Button type="button" icon="pi pi-trash" severity="danger" text onClick={() => remove(i)} />}
            </div>
            <div className="grid">
              <div className="col-4">
                <Controller name={`vacancies.${i}.postName`} control={control} render={({ field: x }) => (
                  <InputText {...x} placeholder="Post Name" className="w-full" />)} />
              </div>
              <div className="col-2">
                <Controller name={`vacancies.${i}.totalSeats`} control={control} render={({ field: x }) => (
                  <InputNumber value={x.value} onValueChange={(e) => x.onChange(e.value)} placeholder="Seats" className="w-full" />)} />
              </div>
              <div className="col-6 flex gap-2">
                {['gen','obc','sc','st','ews'].map((c) => (
                  <Controller key={c} name={`vacancies.${i}.${c}` as any} control={control} render={({ field: x }) => (
                    <InputNumber value={x.value} onValueChange={(e) => x.onChange(e.value)} placeholder={c.toUpperCase()} className="w-full" />)} />
                ))}
              </div>
            </div>
          </div>
        ))}
        <Button type="button" label="Add Vacancy" icon="pi pi-plus" text onClick={() => append(defaults)} />
        <Button type="button" label="Save Draft" icon="pi pi-save" severity="secondary" loading={isSubmitting} onClick={handleSubmit(save)} />
      </form>
    </div>
  );
}
