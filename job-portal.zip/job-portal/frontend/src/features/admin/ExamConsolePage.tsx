import { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import { ProgressBar } from 'primereact/progressbar';
import { Toast } from 'primereact/toast';
import { createCenter, listCenters, runAllocation, startAdmitCardBatch, getJobStatus, type CenterResponse, type BatchJobStatus } from '@/api/exam';

export default function ExamConsolePage() {
  const { notificationId } = useParams();
  const [centers, setCenters] = useState<CenterResponse[]>([]);
  const [visible, setVisible] = useState(false);
  const [nc, setNc] = useState({ name: '', city: '', capacity: 100 });
  const [job, setJob] = useState<BatchJobStatus | null>(null);
  const [allocating, setAllocating] = useState(false);
  const toast = useRef<Toast>(null);
  const timer = useRef<number | null>(null);

  function load() { if (notificationId) listCenters(Number(notificationId)).then(setCenters); }
  useEffect(load, [notificationId]);

  async function add() {
    if (!notificationId) return;
    try {
      await createCenter(Number(notificationId), nc);
      toast.current?.show({ severity: 'success', summary: 'Center added' });
      setVisible(false); setNc({ name: '', city: '', capacity: 100 }); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  async function allocate() {
    if (!notificationId) return;
    setAllocating(true);
    try {
      const r = await runAllocation(Number(notificationId));
      toast.current?.show({ severity: r.unallocated === 0 ? 'success' : 'warn',
        summary: 'Done', detail: `${r.allocated}/${r.totalEligible}` });
      load();
    } finally { setAllocating(false); }
  }

  async function generate() {
    if (!notificationId) return;
    const { jobId } = await startAdmitCardBatch(Number(notificationId));
    timer.current = window.setInterval(async () => {
      const s = await getJobStatus(jobId);
      setJob(s);
      if (s.state === 'COMPLETED' || s.state === 'FAILED') {
        if (timer.current) window.clearInterval(timer.current);
      }
    }, 2000);
  }

  return (
    <div className="p-5">
      <Toast ref={toast} />
      <h2 className="mb-4">Exam Console</h2>
      <div className="flex gap-2 mb-3">
        <Button label="Add Center" icon="pi pi-plus" onClick={() => setVisible(true)} />
        <Button label="Allocate" icon="pi pi-sitemap" severity="warning" loading={allocating} onClick={allocate} />
        <Button label="Generate Admit Cards" icon="pi pi-file-pdf" severity="success" onClick={generate} />
      </div>
      {job && (
        <div className="surface-card p-3 border-round mb-3">
          <p>Job: <b>{job.state}</b> — {job.processed}/{job.total}</p>
          <ProgressBar value={job.total ? Math.round((job.processed / job.total) * 100) : 0} />
        </div>
      )}
      <DataTable value={centers}>
        <Column field="name" header="Center" />
        <Column field="city" header="City" />
        <Column field="capacity" header="Capacity" />
        <Column field="allocatedCount" header="Allocated" />
        <Column field="remaining" header="Remaining" />
      </DataTable>
      <Dialog header="Add Center" visible={visible} onHide={() => setVisible(false)} style={{ width: '420px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setVisible(false)} />
          <Button label="Save" icon="pi pi-check" onClick={add} />
        </div>}>
        <div className="flex flex-column gap-3">
          <InputText value={nc.name} onChange={(e) => setNc({ ...nc, name: e.target.value })} placeholder="Name" />
          <InputText value={nc.city} onChange={(e) => setNc({ ...nc, city: e.target.value })} placeholder="City" />
          <InputNumber value={nc.capacity} onValueChange={(e) => setNc({ ...nc, capacity: e.value ?? 1 })} min={1} className="w-full" />
        </div>
      </Dialog>
    </div>
  );
}
