import { useEffect, useState, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { MultiSelect } from 'primereact/multiselect';
import { Toast } from 'primereact/toast';
import { listUsers, createUser, updateUserRoles, type AdminUser } from '@/api/admin';

const roles = [
  { label: 'Applicant', value: 'APPLICANT' },
  { label: 'Reviewer', value: 'REVIEWER' },
  { label: 'Exam Coordinator', value: 'EXAM_COORD' },
  { label: 'System Admin', value: 'SYS_ADMIN' },
];

export default function UsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [total, setTotal] = useState(0);
  const [state, setState] = useState({ first: 0, rows: 20 });
  const [createVisible, setCreateVisible] = useState(false);
  const [editUser, setEditUser] = useState<AdminUser | null>(null);
  const [form, setForm] = useState({ email: '', mobile: '', password: '', roles: ['APPLICANT'] });
  const [selRoles, setSelRoles] = useState<string[]>([]);
  const toast = useRef<Toast>(null);

  function load() {
    listUsers(Math.floor(state.first / state.rows), state.rows)
      .then((p) => { setUsers(p.content); setTotal(p.totalElements); });
  }
  useEffect(load, [state]);

  async function create() {
    try {
      await createUser(form);
      toast.current?.show({ severity: 'success', summary: 'Created' });
      setCreateVisible(false); setForm({ email: '', mobile: '', password: '', roles: ['APPLICANT'] }); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  async function saveRoles() {
    if (!editUser) return;
    try {
      await updateUserRoles(editUser.id, selRoles);
      toast.current?.show({ severity: 'success', summary: 'Updated' });
      setEditUser(null); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  return (
    <div className="p-5">
      <Toast ref={toast} />
      <div className="flex justify-content-between align-items-center mb-4">
        <h2>User Management</h2>
        <Button label="New User" icon="pi pi-user-plus" onClick={() => setCreateVisible(true)} />
      </div>
      <DataTable value={users} lazy paginator totalRecords={total} first={state.first} rows={state.rows}
        onPage={(e) => setState({ first: e.first, rows: e.rows })}>
        <Column field="email" header="Email" />
        <Column field="mobile" header="Mobile" />
        <Column field="status" header="Status" />
        <Column field="roles" header="Roles" body={(r) => r.roles.join(', ')} />
        <Column header="Action" body={(r) => (
          <Button label="Edit Roles" icon="pi pi-pencil" text onClick={() => { setEditUser(r); setSelRoles(r.roles); }} />
        )} />
      </DataTable>
      <Dialog header="Create User" visible={createVisible} onHide={() => setCreateVisible(false)} style={{ width: '500px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setCreateVisible(false)} />
          <Button label="Create" icon="pi pi-check" onClick={create} />
        </div>}>
        <div className="flex flex-column gap-3">
          <InputText value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email" />
          <InputText value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="Mobile" />
          <Password value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
            toggleMask feedback={false} className="w-full" inputClassName="w-full" />
          <MultiSelect value={form.roles} options={roles}
            onChange={(e) => setForm({ ...form, roles: e.value })} display="chip" />
        </div>
      </Dialog>
      <Dialog header={`Edit Roles: ${editUser?.email ?? ''}`} visible={!!editUser} onHide={() => setEditUser(null)}
        style={{ width: '400px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setEditUser(null)} />
          <Button label="Save" icon="pi pi-check" onClick={saveRoles} />
        </div>}>
        <MultiSelect value={selRoles} options={roles} onChange={(e) => setSelRoles(e.value)} display="chip" className="w-full" />
      </Dialog>
    </div>
  );
}
