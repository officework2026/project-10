import { useEffect, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import apiClient from '@/api/client';

interface AuditLog { id: number; actorId?: number; action: string; entity: string; entityId?: number; afterVal?: Record<string, unknown>; createdAt: string; }

export default function AuditLogPage() {
  const [items, setItems] = useState<AuditLog[]>([]);
  const [total, setTotal] = useState(0);
  const [state, setState] = useState({ first: 0, rows: 50 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    apiClient.get('/admin/audit-logs', { params: { page: Math.floor(state.first / state.rows), size: state.rows } })
      .then((r) => { setItems(r.data.content); setTotal(r.data.totalElements); })
      .finally(() => setLoading(false));
  }, [state]);

  return (
    <div className="p-5">
      <h2 className="mb-4">Audit Log</h2>
      <DataTable value={items} lazy paginator loading={loading} totalRecords={total}
        first={state.first} rows={state.rows} onPage={(e) => setState({ first: e.first, rows: e.rows })}>
        <Column field="createdAt" header="Time" body={(r) => new Date(r.createdAt).toLocaleString()} />
        <Column field="actorId" header="Actor" />
        <Column field="action" header="Action" body={(r) => <Tag value={r.action} severity="info" />} />
        <Column field="entity" header="Entity" />
        <Column field="entityId" header="ID" />
      </DataTable>
    </div>
  );
}
