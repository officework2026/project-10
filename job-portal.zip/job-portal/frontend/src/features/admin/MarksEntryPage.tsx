import { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputNumber } from 'primereact/inputnumber';
import { Checkbox } from 'primereact/checkbox';
import { Toast } from 'primereact/toast';
import { listResults, enterMarks, publishResult, publishAllResults } from '@/api/result';

export default function MarksEntryPage() {
  const { notificationId } = useParams();
  const [rows, setRows] = useState<any[]>([]);
  const [selectedApp, setSelectedApp] = useState<any>(null);
  const [marks, setMarks] = useState<Record<string, number>>({ written: 0, interview: 0 });
  const [qualified, setQualified] = useState(false);
  const [visible, setVisible] = useState(false);
  const toast = useRef<Toast>(null);

  function load() { if (notificationId) listResults(Number(notificationId)).then((p) => setRows(p.content)); }
  useEffect(load, [notificationId]);

  function open(row: any) { setSelectedApp(row); setMarks({ written: 0, interview: 0 }); setQualified(false); setVisible(true); }

  async function save() {
    const total = Object.values(marks).reduce((a, b) => a + b, 0);
    try {
      await enterMarks(selectedApp.applicationId, { marks, total, qualified });
      toast.current?.show({ severity: 'success', summary: 'Saved' });
      setVisible(false); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  async function publishOne(id: number) {
    try { await publishResult(id); load(); } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  async function publishAll() {
    if (!notificationId) return;
    const count = await publishAllResults(Number(notificationId));
    toast.current?.show({ severity: 'success', summary: `Published ${count} results` });
    load();
  }

  return (
    <div className="p-5">
      <Toast ref={toast} />
      <div className="flex justify-content-between align-items-center mb-4">
        <h2>Marks Entry — Notification #{notificationId}</h2>
        <Button label="Publish All" icon="pi pi-send" severity="success" onClick={publishAll} />
      </div>
      <DataTable value={rows}>
        <Column field="postName" header="Post" />
        <Column field="applicationId" header="App ID" />
        <Column field="total" header="Total" />
        <Column field="qualified" header="Qualified" body={(r) => r.qualified ? 'Yes' : 'No'} />
        <Column field="publishedAt" header="Published" body={(r) => r.publishedAt ? new Date(r.publishedAt).toLocaleDateString() : '—'} />
        <Column header="Action" body={(r) => (
          <div className="flex gap-1">
            <Button icon="pi pi-pencil" text onClick={() => open(r)} />
            {!r.publishedAt && <Button icon="pi pi-send" text severity="success" onClick={() => publishOne(r.id)} />}
          </div>
        )} />
      </DataTable>
      <Dialog header="Enter Marks" visible={visible} onHide={() => setVisible(false)} style={{ width: '400px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setVisible(false)} />
          <Button label="Save" icon="pi pi-check" onClick={save} />
        </div>}>
        <div className="flex flex-column gap-3">
          {Object.keys(marks).map((stage) => (
            <div key={stage}>
              <label className="block mb-1">{stage}</label>
              <InputNumber value={marks[stage]} onValueChange={(e) => setMarks({ ...marks, [stage]: e.value ?? 0 })} className="w-full" />
            </div>
          ))}
          <div className="flex align-items-center gap-2">
            <Checkbox checked={qualified} onChange={(e) => setQualified(!!e.checked)} />
            <label>Qualified</label>
          </div>
        </div>
      </Dialog>
    </div>
  );
}
