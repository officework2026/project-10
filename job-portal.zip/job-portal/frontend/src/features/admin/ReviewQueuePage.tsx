import { useEffect, useState, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputTextarea } from 'primereact/inputtextarea';
import { Toast } from 'primereact/toast';
import { fetchReviewQueue, approveApplication, rejectApplication, batchReview, type ReviewItem } from '@/api/review';

export default function ReviewQueuePage() {
  const [items, setItems] = useState<ReviewItem[]>([]);
  const [total, setTotal] = useState(0);
  const [state, setState] = useState({ first: 0, rows: 20 });
  const [selected, setSelected] = useState<ReviewItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialog, setDialog] = useState<{ action: 'approve'|'reject'|'batch'; ids: number[] } | null>(null);
  const [remarks, setRemarks] = useState('');
  const toast = useRef<Toast>(null);

  function load() {
    setLoading(true);
    fetchReviewQueue({ page: Math.floor(state.first / state.rows), size: state.rows })
      .then((d) => { setItems(d.content); setTotal(d.totalElements); })
      .finally(() => setLoading(false));
  }
  useEffect(load, [state]);

  async function confirm() {
    if (!dialog) return;
    try {
      if (dialog.action === 'approve') await approveApplication(dialog.ids[0], remarks);
      else if (dialog.action === 'reject') await rejectApplication(dialog.ids[0], remarks);
      else await batchReview(dialog.ids, 'ELIGIBLE', remarks);
      toast.current?.show({ severity: 'success', summary: 'Done' });
      setDialog(null); setSelected([]); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  return (
    <div className="p-5">
      <Toast ref={toast} />
      <div className="flex justify-content-between align-items-center mb-4">
        <h2>Review Queue</h2>
        {selected.length > 0 && (
          <Button label={`Batch Approve (${selected.length})`} icon="pi pi-check-circle" severity="success"
            onClick={() => { setRemarks(''); setDialog({ action: 'batch', ids: selected.map((s) => s.id) }); }} />
        )}
      </div>
      <DataTable value={items} lazy paginator loading={loading} totalRecords={total}
        first={state.first} rows={state.rows} onPage={(e) => setState({ first: e.first, rows: e.rows })}
        selection={selected} onSelectionChange={(e) => setSelected(e.value as ReviewItem[])}
        dataKey="id" emptyMessage="No pending applications">
        <Column selectionMode="multiple" />
        <Column field="notificationTitle" header="Notification" />
        <Column field="department" header="Department" />
        <Column field="postName" header="Post" />
        <Column field="status" header="Status" body={(r) => <Tag value={r.status.replace(/_/g, ' ')} severity="warning" />} />
        <Column header="Actions" body={(r) => (
          <div className="flex gap-1">
            <Button icon="pi pi-check" severity="success" text onClick={() => { setRemarks(''); setDialog({ action: 'approve', ids: [r.id] }); }} />
            <Button icon="pi pi-times" severity="danger" text onClick={() => { setRemarks(''); setDialog({ action: 'reject', ids: [r.id] }); }} />
          </div>
        )} />
      </DataTable>
      <Dialog header={dialog?.action ?? 'Review'} visible={!!dialog} onHide={() => setDialog(null)} style={{ width: '450px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setDialog(null)} />
          <Button label="Confirm" icon="pi pi-check" onClick={confirm} />
        </div>}>
        <InputTextarea rows={3} className="w-full" value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Remarks" />
      </Dialog>
    </div>
  );
}
