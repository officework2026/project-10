import { useState, useRef } from 'react';
import { Card } from 'primereact/card';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { downloadReport } from '@/api/admin';

const types = [
  { label: 'Applications by Category', value: 'by-category' },
  { label: 'Applications by Gender', value: 'by-gender' },
  { label: 'Fee Collection', value: 'fee-collection' },
  { label: 'Vacancy Fill Rate', value: 'vacancy-fill' },
];

export default function ReportsPage() {
  const [type, setType] = useState('by-category');
  const [notificationId, setNotificationId] = useState<number | null>(null);
  const toast = useRef<Toast>(null);

  async function download(format: 'csv'|'pdf') {
    if (!notificationId) {
      toast.current?.show({ severity: 'warn', summary: 'Notification ID required' });
      return;
    }
    try {
      const blob = await downloadReport(type as any, notificationId, format);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `${type}-${notificationId}.${format}`; a.click();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Failed', detail: e.response?.data?.message });
    }
  }

  return (
    <div className="p-5 max-w-3xl mx-auto">
      <Toast ref={toast} />
      <h2 className="mb-4">Reports</h2>
      <Card>
        <div className="flex flex-column gap-3">
          <div>
            <label className="block mb-1">Report</label>
            <Dropdown value={type} onChange={(e) => setType(e.value)} options={types} className="w-full" />
          </div>
          <div>
            <label className="block mb-1">Notification ID</label>
            <InputNumber value={notificationId} onValueChange={(e) => setNotificationId(e.value ?? null)} className="w-full" />
          </div>
          <div className="flex gap-2">
            <Button label="Download CSV" icon="pi pi-file" onClick={() => download('csv')} />
            <Button label="Download PDF" icon="pi pi-file-pdf" severity="secondary" onClick={() => download('pdf')} />
          </div>
        </div>
      </Card>
    </div>
  );
}
