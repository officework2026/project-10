import { useEffect, useState, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { listConfig, updateConfig, type ConfigItem } from '@/api/admin';

export default function SystemConfigPage() {
  const [items, setItems] = useState<ConfigItem[]>([]);
  const [edits, setEdits] = useState<Record<string, string>>({});
  const toast = useRef<Toast>(null);

  useEffect(() => { listConfig().then(setItems); }, []);

  async function save(k: string) {
    try {
      await updateConfig(k, edits[k]);
      toast.current?.show({ severity: 'success', summary: 'Saved', detail: k });
      setEdits((p) => { const c = { ...p }; delete c[k]; return c; });
      listConfig().then(setItems);
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  return (
    <div className="p-5">
      <Toast ref={toast} />
      <h2 className="mb-4">System Configuration</h2>
      <DataTable value={items} dataKey="key">
        <Column field="key" header="Key" />
        <Column field="description" header="Description" />
        <Column header="Value" body={(r) => (
          <InputText value={edits[r.key] ?? r.value} onChange={(e) => setEdits({ ...edits, [r.key]: e.target.value })} />
        )} />
        <Column header="Action" body={(r) => (
          <Button label="Save" icon="pi pi-check" disabled={edits[r.key] === undefined} onClick={() => save(r.key)} />
        )} />
      </DataTable>
    </div>
  );
}
