import { useEffect, useState, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputTextarea } from 'primereact/inputtextarea';
import { Toast } from 'primereact/toast';
import { listObjections, resolveObjection } from '@/api/result';

export default function ObjectionsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [visible, setVisible] = useState(false);
  const [remarks, setRemarks] = useState('');
  const [action, setAction] = useState<'ACCEPTED'|'REJECTED'>('ACCEPTED');
  const toast = useRef<Toast>(null);

  function load() { listObjections('SUBMITTED').then((p) => setItems(p.content)); }
  useEffect(load, []);

  async function resolve() {
    try {
      await resolveObjection(selected.id, action, remarks);
      toast.current?.show({ severity: 'success', summary: 'Resolved' });
      setVisible(false); load();
    } catch (e: any) {
      toast.current?.show({ severity: 'error', summary: 'Error', detail: e.response?.data?.message });
    }
  }

  return (
    <div className="p-5">
      <Toast ref={toast} />
      <h2 className="mb-4">Pending Objections</h2>
      <DataTable value={items} emptyMessage="No pending objections">
        <Column field="questionRef" header="Question" />
        <Column field="justification" header="Justification" />
        <Column field="status" header="Status" body={(r) => <Tag value={r.status} severity="warning" />} />
        <Column header="Resolve" body={(r) => (
          <div className="flex gap-1">
            <Button icon="pi pi-check" severity="success" text
              onClick={() => { setSelected(r); setAction('ACCEPTED'); setRemarks(''); setVisible(true); }} />
            <Button icon="pi pi-times" severity="danger" text
              onClick={() => { setSelected(r); setAction('REJECTED'); setRemarks(''); setVisible(true); }} />
          </div>
        )} />
      </DataTable>
      <Dialog header={action} visible={visible} onHide={() => setVisible(false)} style={{ width: '450px' }}
        footer={<div className="flex justify-end gap-2">
          <Button label="Cancel" text onClick={() => setVisible(false)} />
          <Button label="Confirm" icon="pi pi-check" onClick={resolve} />
        </div>}>
        <InputTextarea rows={3} className="w-full" value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Admin remarks" />
      </Dialog>
    </div>
  );
}
