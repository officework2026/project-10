# Frontend — React + PrimeReact

## Run
```bash
npm install
npm run dev
```
Open http://localhost:3000. API proxy → http://localhost:8080.

## Stack
React 19.2.7, Vite 8.1.1, PrimeReact 10.9.9, TailwindCSS 4, react-hook-form, zod, axios.

## Styling — Critical Layer Order
```css
@layer theme, base, primereact, components, utilities;
```
PrimeReact theme must come between Tailwind base and utilities.

## PrimeReact + RHF Composite Inputs
For Dropdown/Calendar/Password/InputNumber, use explicit onChange:
```tsx
<Controller name="x" control={control} render={({ field }) => (
  <Dropdown value={field.value} onChange={(e) => field.onChange(e.value)} />
)} />
```
