# Deployment Runbook

1. Build: `mvn clean package` → `target/job-portal.jar`
2. Flyway runs on startup (validate schema first)
3. Deploy to instance A, health check
4. Deploy to instance B, health check
5. Smoke test (12 checks)
6. Purge CDN cache for frontend
