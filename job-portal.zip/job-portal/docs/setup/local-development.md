# Local Development Setup

## Prerequisites
- Java 25 (required — Spring Boot 4.0.1 + MapStruct 1.6.3 fails on Java 21)
- Node 22.15+
- Docker 24+

## Steps
1. `docker compose up -d` (starts Postgres, Redis, MinIO)
2. `cd backend && ./mvnw spring-boot:run -Dspring-boot.run.profiles=dev`
3. `cd frontend && npm install && npm run dev`
4. Open http://localhost:3000

## Dev users (password: password123)
| Email | Role |
|-------|------|
| admin@test.com | SYS_ADMIN |
| reviewer@test.com | REVIEWER |
| exam@test.com | EXAM_COORD |
| applicant@test.com | APPLICANT |

Auto-seeded by `DevDataSeeder` on first run in dev profile.

## Reset
```bash
docker compose down -v && docker compose up -d
```
