# Online Government Job Portal

Full-stack government recruitment platform. Applicant + Administrator roles.

## Stack
- Backend: Java 25, Spring Boot 4.0.1, Spring Security 7, JPA, MapStruct 1.6.3
- DB: PostgreSQL 15, Redis 7, MinIO
- Frontend: React 19.2.7, Vite 8.1.1, PrimeReact 10.9.9, TailwindCSS 4

## Quick Start
```bash
docker compose up -d
cd backend && ./mvnw spring-boot:run
cd frontend && npm install && npm run dev
```

See `backend/README.md`, `frontend/README.md`, `docs/setup/local-development.md` for details.

**Dev users (password: password123):**
| Email | Role |
|-------|------|
| admin@test.com | SYS_ADMIN |
| reviewer@test.com | REVIEWER |
| exam@test.com | EXAM_COORD |
| applicant@test.com | APPLICANT |
