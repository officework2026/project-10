package com.gov.portal.exam.dto;

public record CenterResponse(
    Long id, Long notificationId, String name, String city,
    Integer capacity, Integer allocatedCount, Integer remaining
) {}
