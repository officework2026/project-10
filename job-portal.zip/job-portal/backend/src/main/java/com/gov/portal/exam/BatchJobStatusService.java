package com.gov.portal.exam;

import com.gov.portal.exam.dto.BatchJobStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

@Service
public class BatchJobStatusService {
    private final JdbcTemplate jdbc;
    public BatchJobStatusService(JdbcTemplate j) { this.jdbc = j; }

    public void start(String jobId, int total) {
        jdbc.update("INSERT INTO batch_job (job_id, state, total, started_at) VALUES (?, 'RUNNING', ?, now())",
            jobId, total);
    }
    public void progress(String jobId, int processed) {
        jdbc.update("UPDATE batch_job SET processed = ? WHERE job_id = ?", processed, jobId);
    }
    public void complete(String jobId, int processed, int total) {
        jdbc.update("UPDATE batch_job SET state = 'COMPLETED', processed = ?, total = ?, completed_at = now() WHERE job_id = ?",
            processed, total, jobId);
    }
    public void fail(String jobId, String error) {
        jdbc.update("UPDATE batch_job SET state = 'FAILED', completed_at = now(), error_message = ? WHERE job_id = ?",
            error, jobId);
    }
    public BatchJobStatus get(String jobId) {
        List<BatchJobStatus> rows = jdbc.query(
            "SELECT job_id, state, processed, total, started_at, completed_at, error_message FROM batch_job WHERE job_id = ?",
            (rs, i) -> new BatchJobStatus(
                rs.getString("job_id"), rs.getString("state"),
                rs.getInt("processed"), rs.getInt("total"),
                toInstant(rs.getTimestamp("started_at")),
                toInstant(rs.getTimestamp("completed_at")),
                rs.getString("error_message")),
            jobId);
        return rows.isEmpty() ? null : rows.get(0);
    }
    private Instant toInstant(Timestamp t) { return t == null ? null : t.toInstant(); }
}
