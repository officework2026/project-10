package com.gov.portal.document.entity;

import com.gov.portal.application.entity.Application;
import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "application_document")
public class ApplicationDocument {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "application_id", nullable = false)
    private Application application;
    @Column(name = "document_type", nullable = false, length = 50) private String documentType;
    @Column(name = "object_key", nullable = false) private String objectKey;
    @Column(name = "original_name") private String originalName;
    @Column(name = "content_type", length = 100) private String contentType;
    @Column(name = "file_size") private Long fileSize;
    @Column(name = "uploaded_at", nullable = false, updatable = false) private Instant uploadedAt = Instant.now();

    public Long getId() { return id; }
    public Application getApplication() { return application; }
    public void setApplication(Application a) { this.application = a; }
    public String getDocumentType() { return documentType; }
    public void setDocumentType(String d) { this.documentType = d; }
    public String getObjectKey() { return objectKey; }
    public void setObjectKey(String o) { this.objectKey = o; }
    public String getOriginalName() { return originalName; }
    public void setOriginalName(String n) { this.originalName = n; }
    public String getContentType() { return contentType; }
    public void setContentType(String c) { this.contentType = c; }
    public Long getFileSize() { return fileSize; }
    public void setFileSize(Long s) { this.fileSize = s; }
}
