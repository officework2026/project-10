package com.gov.portal.security;

import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.common.ResourceNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component("ownershipGuard")
public class OwnershipGuard {
    private final ApplicationRepository applicationRepo;
    public OwnershipGuard(ApplicationRepository r) { this.applicationRepo = r; }

    public boolean isOwner(Long applicationId) {
        Authentication a = SecurityContextHolder.getContext().getAuthentication();
        if (a == null || !a.isAuthenticated()) return false;
        return applicationRepo.findById(applicationId)
            .map(app -> app.getApplicant().getUser().getEmail().equals(a.getName()))
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
    }

    public boolean isAdmin() {
        Authentication a = SecurityContextHolder.getContext().getAuthentication();
        return a != null && a.getAuthorities().stream()
            .anyMatch(x -> x.getAuthority().equals("ROLE_SYS_ADMIN"));
    }
}
