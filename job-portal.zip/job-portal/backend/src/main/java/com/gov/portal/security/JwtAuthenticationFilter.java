package com.gov.portal.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwt;
    private final UserDetailsService userDetails;

    public JwtAuthenticationFilter(JwtService jwt, UserDetailsService userDetails) {
        this.jwt = jwt; this.userDetails = userDetails;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest req,
                                    @NonNull HttpServletResponse res,
                                    @NonNull FilterChain chain)
            throws ServletException, IOException {
        String h = req.getHeader("Authorization");
        if (h == null || !h.startsWith("Bearer ")) { chain.doFilter(req, res); return; }
        String token = h.substring(7);
        try {
            String u = jwt.extractUsername(token);
            if (u != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails ud = userDetails.loadUserByUsername(u);
                if (jwt.isTokenValid(token, ud)) {
                    var a = new UsernamePasswordAuthenticationToken(ud, null, ud.getAuthorities());
                    a.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
                    SecurityContextHolder.getContext().setAuthentication(a);
                }
            }
        } catch (Exception ignored) {}
        chain.doFilter(req, res);
    }
}
