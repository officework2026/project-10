package com.gov.portal.admin;

import com.gov.portal.admin.entity.NotificationTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/templates")
@PreAuthorize("hasRole('SYS_ADMIN')")
public class AdminTemplateController {
    private final NotificationTemplateService svc;
    public AdminTemplateController(NotificationTemplateService s) { this.svc = s; }

    @GetMapping
    public List<NotificationTemplate> list() { return svc.listAll(); }

    @PutMapping("/{id}")
    public NotificationTemplate update(@PathVariable Long id,
                                       @RequestParam String subject, @RequestParam String body) {
        return svc.update(id, subject, body);
    }
}
