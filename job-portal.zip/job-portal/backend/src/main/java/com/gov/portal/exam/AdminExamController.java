package com.gov.portal.exam;

import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.exam.dto.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin/exam")
@PreAuthorize("hasAnyRole('EXAM_COORD','SYS_ADMIN')")
public class AdminExamController {
    private final CenterService centerService;
    private final CenterAllocationService allocService;
    private final AdmitCardBatchService batchService;
    private final BatchJobStatusService jobStatus;

    public AdminExamController(CenterService c, CenterAllocationService a,
                               AdmitCardBatchService b, BatchJobStatusService j) {
        this.centerService = c; this.allocService = a;
        this.batchService = b; this.jobStatus = j;
    }

    @PostMapping("/notifications/{id}/centers")
    @ResponseStatus(HttpStatus.CREATED)
    public CenterResponse addCenter(@PathVariable Long id, @Valid @RequestBody CenterRequest r) {
        return centerService.create(id, r);
    }

    @GetMapping("/notifications/{id}/centers")
    public List<CenterResponse> centers(@PathVariable Long id) { return centerService.list(id); }

    @PostMapping("/notifications/{id}/allocate")
    public AllocationResult allocate(@PathVariable Long id) { return allocService.allocate(id); }

    @PostMapping("/notifications/{id}/admit-cards/generate")
    public ResponseEntity<Map<String, String>> generate(@PathVariable Long id) {
        String jobId = UUID.randomUUID().toString();
        batchService.generateBatch(id, jobId);
        return ResponseEntity.accepted().body(Map.of("jobId", jobId));
    }

    @GetMapping("/jobs/{jobId}")
    public BatchJobStatus job(@PathVariable String jobId) {
        var s = jobStatus.get(jobId);
        if (s == null) throw new ResourceNotFoundException("Job not found");
        return s;
    }
}
