package com.gov.portal.auth.dto;

import jakarta.validation.constraints.*;

public record RegisterRequest(
    @NotBlank @Email String email,
    @NotBlank @Pattern(regexp = "^[6-9]\\d{9}$", message = "Invalid Indian mobile") String mobile,
    @NotBlank @Size(min = 8, max = 100) String password
) {}
