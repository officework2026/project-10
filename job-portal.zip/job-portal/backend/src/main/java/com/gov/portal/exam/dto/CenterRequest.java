package com.gov.portal.exam.dto;

import jakarta.validation.constraints.*;

public record CenterRequest(
    @NotBlank String name, @NotBlank String city, @NotNull @Min(1) Integer capacity
) {}
