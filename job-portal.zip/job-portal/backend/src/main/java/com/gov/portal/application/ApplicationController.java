package com.gov.portal.application;

import com.gov.portal.application.dto.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/applications")
public class ApplicationController {
    private final ApplicationService svc;
    public ApplicationController(ApplicationService s) { this.svc = s; }

    @GetMapping("/eligibility/{vacancyId}")
    public EligibilityCheckResponse check(@PathVariable Long vacancyId, Authentication a) {
        return svc.checkEligibility(vacancyId, a.getName());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApplicationResponse apply(@Valid @RequestBody ApplyRequest r, Authentication a) {
        return svc.apply(r, a.getName());
    }

    @GetMapping
    public Page<ApplicationResponse> list(Authentication a,
        @PageableDefault(size = 20, sort = "appliedAt") Pageable p) {
        return svc.myApplications(a.getName(), p);
    }
}
