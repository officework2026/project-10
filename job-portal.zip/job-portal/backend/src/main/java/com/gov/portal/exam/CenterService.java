package com.gov.portal.exam;

import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.exam.dto.*;
import com.gov.portal.exam.entity.ExamCenter;
import com.gov.portal.exam.repository.ExamCenterRepository;
import com.gov.portal.recruitment.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CenterService {
    private final ExamCenterRepository centerRepo;
    private final NotificationRepository notifRepo;

    public CenterService(ExamCenterRepository c, NotificationRepository n) {
        this.centerRepo = c; this.notifRepo = n;
    }

    @Transactional
    public CenterResponse create(Long notificationId, CenterRequest r) {
        var n = notifRepo.findById(notificationId)
            .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        var c = new ExamCenter();
        c.setNotification(n);
        c.setName(r.name());
        c.setCity(r.city());
        c.setCapacity(r.capacity());
        c.setAllocatedCount(0);
        return toResponse(centerRepo.save(c));
    }

    @Transactional(readOnly = true)
    public List<CenterResponse> list(Long notificationId) {
        return centerRepo.findByNotificationId(notificationId).stream().map(this::toResponse).toList();
    }

    private CenterResponse toResponse(ExamCenter c) {
        return new CenterResponse(c.getId(), c.getNotification().getId(),
            c.getName(), c.getCity(), c.getCapacity(), c.getAllocatedCount(), c.remaining());
    }
}
