package com.gov.portal.review.dto;

import jakarta.validation.constraints.*;
import java.util.List;

public record BatchReviewRequest(
    @NotEmpty List<Long> applicationIds,
    @NotBlank @Pattern(regexp = "ELIGIBLE|REJECTED") String targetStatus,
    @Size(max = 500) String remarks
) {}
