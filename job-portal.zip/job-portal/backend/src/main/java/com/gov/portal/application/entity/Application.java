package com.gov.portal.application.entity;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.recruitment.entity.Vacancy;
import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "application",
    uniqueConstraints = @UniqueConstraint(columnNames = {"applicant_id","vacancy_id"}))
public class Application {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "applicant_id", nullable = false)
    private ApplicantProfile applicant;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "vacancy_id", nullable = false)
    private Vacancy vacancy;
    @Column(nullable = false, length = 30) private String status = "SUBMITTED";
    @Column(name = "review_remarks", columnDefinition = "TEXT") private String reviewRemarks;
    @Column(name = "applied_at", nullable = false, updatable = false) private Instant appliedAt = Instant.now();
    @Version private Long version;

    public Long getId() { return id; }
    public ApplicantProfile getApplicant() { return applicant; }
    public void setApplicant(ApplicantProfile a) { this.applicant = a; }
    public Vacancy getVacancy() { return vacancy; }
    public void setVacancy(Vacancy v) { this.vacancy = v; }
    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }
    public String getReviewRemarks() { return reviewRemarks; }
    public void setReviewRemarks(String r) { this.reviewRemarks = r; }
    public Instant getAppliedAt() { return appliedAt; }
}
