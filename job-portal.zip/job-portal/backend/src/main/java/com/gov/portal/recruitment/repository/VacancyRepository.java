package com.gov.portal.recruitment.repository;

import com.gov.portal.recruitment.entity.Vacancy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VacancyRepository extends JpaRepository<Vacancy, Long> {}
