package com.gov.portal.application.rule;

public record Violation(String code, String message) {}
