package com.gov.portal.document;

import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.document.entity.ApplicationDocument;
import com.gov.portal.document.repository.ApplicationDocumentRepository;
import io.minio.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class DocumentService {
    private final ApplicationDocumentRepository docRepo;
    private final ApplicationRepository appRepo;
    private final MinioClient minio;

    @Value("${app.storage.bucket}") private String bucket;

    public DocumentService(ApplicationDocumentRepository d, ApplicationRepository a, MinioClient m) {
        this.docRepo = d; this.appRepo = a; this.minio = m;
    }

    public String presign(Long applicationId, String documentType) {
        var app = appRepo.findById(applicationId)
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
        String key = "documents/%d/%d/%s_%s".formatted(app.getApplicant().getId(),
            applicationId, documentType, UUID.randomUUID().toString().substring(0, 8));
        try {
            boolean exists = minio.bucketExists(BucketExistsArgs.builder().bucket(bucket).build());
            if (!exists) minio.makeBucket(MakeBucketArgs.builder().bucket(bucket).build());
            String url = minio.getPresignedObjectUrl(
                GetPresignedObjectUrlArgs.builder()
                    .method(io.minio.http.Method.PUT)
                    .bucket(bucket).object(key).expiry(15 * 60).build());
            return url + "|" + key;
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate upload URL", e);
        }
    }

    public ApplicationDocument confirm(Long applicationId, String documentType, String objectKey,
                                       String originalName, String contentType, Long fileSize) {
        var app = appRepo.findById(applicationId)
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
        var doc = new ApplicationDocument();
        doc.setApplication(app);
        doc.setDocumentType(documentType);
        doc.setObjectKey(objectKey);
        doc.setOriginalName(originalName);
        doc.setContentType(contentType);
        doc.setFileSize(fileSize);
        return docRepo.save(doc);
    }
}
