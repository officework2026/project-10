package com.gov.portal.review.dto;

import jakarta.validation.constraints.Size;

public record ReviewRequest(@Size(max = 500) String remarks) {}
