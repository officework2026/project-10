package com.gov.portal.exam;

import com.gov.portal.application.entity.Application;
import com.gov.portal.exam.dto.AdmitCardResponse;
import com.gov.portal.exam.entity.AdmitCard;
import com.gov.portal.exam.entity.ExamCenter;
import com.gov.portal.exam.repository.AdmitCardRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class AdmitCardService {
    private final AdmitCardRepository admitRepo;
    private final JdbcTemplate jdbc;

    public AdmitCardService(AdmitCardRepository a, JdbcTemplate j) {
        this.admitRepo = a; this.jdbc = j;
    }

    public String generateRollNumber() {
        Long seq = jdbc.queryForObject("SELECT nextval('roll_number_seq')", Long.class);
        return String.format("R%09d", seq);
    }

    @Transactional
    public AdmitCard create(Application app, ExamCenter center, String rollNumber) {
        var c = new AdmitCard();
        c.setApplication(app);
        c.setExamCenter(center);
        c.setRollNumber(rollNumber);
        c.setExamDate(center.getNotification().getOpenDate());
        c.setQrPayload("roll=" + rollNumber + "&app=" + app.getId() + "&center=" + center.getId());
        return admitRepo.save(c);
    }

    @Transactional(readOnly = true)
    public Optional<AdmitCardResponse> findByApplication(Long applicationId) {
        return admitRepo.findByApplicationId(applicationId).map(c -> new AdmitCardResponse(
            c.getId(), c.getApplication().getId(), c.getRollNumber(),
            c.getExamCenter().getName(), c.getExamCenter().getCity(),
            c.getExamDate(), c.getQrPayload(), c.getObjectKey() != null));
    }
}
