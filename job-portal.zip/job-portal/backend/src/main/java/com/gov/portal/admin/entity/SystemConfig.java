package com.gov.portal.admin.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "system_config")
public class SystemConfig {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "config_key", nullable = false, unique = true, length = 100) private String configKey;
    @Column(name = "config_value", nullable = false, columnDefinition = "TEXT") private String configValue;
    private String description;
    @Column(name = "updated_by") private Long updatedBy;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt = Instant.now();

    public Long getId() { return id; }
    public String getConfigKey() { return configKey; }
    public void setConfigKey(String k) { this.configKey = k; }
    public String getConfigValue() { return configValue; }
    public void setConfigValue(String v) { this.configValue = v; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public Long getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(Long u) { this.updatedBy = u; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant t) { this.updatedAt = t; }
}
