package com.gov.portal.application.dto;

import java.time.Instant;

public record ApplicationResponse(
    Long id, Long vacancyId, String postName, String department,
    String notificationTitle, String status, String reviewRemarks, Instant appliedAt
) {}
