package com.gov.portal.applicant.entity;

import com.gov.portal.user.entity.User;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Entity
@Table(name = "applicant_profile")
public class ApplicantProfile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;
    @Column(name = "full_name", nullable = false, length = 150) private String fullName;
    @Column(nullable = false) private LocalDate dob;
    @Column(length = 20) private String category;
    @Column(length = 10) private String gender;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private List<Map<String, Object>> education;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private List<Map<String, Object>> experience;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private Map<String, Object> address;
    @Column(name = "otr_completed", nullable = false) private boolean otrCompleted;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();
    @Column(name = "updated_at", nullable = false) private Instant updatedAt = Instant.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public User getUser() { return user; }
    public void setUser(User u) { this.user = u; }
    public String getFullName() { return fullName; }
    public void setFullName(String f) { this.fullName = f; }
    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate d) { this.dob = d; }
    public String getCategory() { return category; }
    public void setCategory(String c) { this.category = c; }
    public String getGender() { return gender; }
    public void setGender(String g) { this.gender = g; }
    public List<Map<String, Object>> getEducation() { return education; }
    public void setEducation(List<Map<String, Object>> e) { this.education = e; }
    public List<Map<String, Object>> getExperience() { return experience; }
    public void setExperience(List<Map<String, Object>> e) { this.experience = e; }
    public Map<String, Object> getAddress() { return address; }
    public void setAddress(Map<String, Object> a) { this.address = a; }
    public boolean isOtrCompleted() { return otrCompleted; }
    public void setOtrCompleted(boolean b) { this.otrCompleted = b; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant t) { this.updatedAt = t; }
}
