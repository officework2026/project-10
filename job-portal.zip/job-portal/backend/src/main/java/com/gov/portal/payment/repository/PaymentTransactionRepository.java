package com.gov.portal.payment.repository;

import com.gov.portal.payment.entity.PaymentTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {
    Optional<PaymentTransaction> findByApplicationId(Long applicationId);
    Optional<PaymentTransaction> findByGatewayRef(String gatewayRef);
}
