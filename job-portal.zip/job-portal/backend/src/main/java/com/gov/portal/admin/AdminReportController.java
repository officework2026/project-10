package com.gov.portal.admin;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/reports")
@PreAuthorize("hasRole('SYS_ADMIN')")
public class AdminReportController {
    private final ReportService svc;
    public AdminReportController(ReportService s) { this.svc = s; }

    @GetMapping("/{type}")
    public ResponseEntity<byte[]> generate(@PathVariable String type,
                                           @RequestParam Long notificationId,
                                           @RequestParam(defaultValue = "csv") String format) {
        byte[] data; MediaType mt; String filename;
        if ("pdf".equals(format)) {
            data = svc.applicationsByCategoryPdf(notificationId);
            mt = MediaType.APPLICATION_PDF;
            filename = type + "-" + notificationId + ".pdf";
        } else {
            data = switch (type) {
                case "by-category" -> svc.applicationsByCategoryCsv(notificationId);
                case "by-gender" -> svc.applicationsByGenderCsv(notificationId);
                case "fee-collection" -> svc.feeCollectionCsv(notificationId);
                case "vacancy-fill" -> svc.vacancyFillRateCsv(notificationId);
                default -> throw new IllegalArgumentException("Unknown report type: " + type);
            };
            mt = MediaType.parseMediaType("text/csv");
            filename = type + "-" + notificationId + ".csv";
        }
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
            .contentType(mt).body(data);
    }
}
