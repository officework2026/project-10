package com.gov.portal.exam.repository;

import com.gov.portal.exam.entity.AdmitCard;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface AdmitCardRepository extends JpaRepository<AdmitCard, Long> {
    Optional<AdmitCard> findByApplicationId(Long applicationId);
}
