package com.gov.portal.application;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.applicant.repository.ApplicantProfileRepository;
import com.gov.portal.application.dto.*;
import com.gov.portal.application.entity.Application;
import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.application.rule.EligibilityEvaluator;
import com.gov.portal.common.IneligibleException;
import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.recruitment.entity.Vacancy;
import com.gov.portal.recruitment.repository.VacancyRepository;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class ApplicationService {
    private final ApplicationRepository appRepo;
    private final ApplicantProfileRepository profRepo;
    private final VacancyRepository vacRepo;
    private final UserRepository userRepo;
    private final EligibilityEvaluator evaluator;

    public ApplicationService(ApplicationRepository a, ApplicantProfileRepository p,
                              VacancyRepository v, UserRepository u, EligibilityEvaluator e) {
        this.appRepo = a; this.profRepo = p; this.vacRepo = v;
        this.userRepo = u; this.evaluator = e;
    }

    @Transactional(readOnly = true)
    public EligibilityCheckResponse checkEligibility(Long vacancyId, String email) {
        var p = resolveProfile(email);
        var v = resolveVacancy(vacancyId);
        var violations = evaluator.evaluate(p, v, v.getNotification().getCloseDate());
        return new EligibilityCheckResponse(violations.isEmpty(), violations);
    }

    @Transactional
    public ApplicationResponse apply(ApplyRequest r, String email) {
        if (!r.declarationAccepted()) throw new IllegalArgumentException("Declaration required");
        var p = resolveProfile(email);
        if (!p.isOtrCompleted()) throw new IllegalStateException("Complete OTR first");
        var v = resolveVacancy(r.vacancyId());
        var n = v.getNotification();
        if (!"PUBLISHED".equals(n.getStatus()))
            throw new IllegalStateException("Not open");
        var today = LocalDate.now();
        if (today.isBefore(n.getOpenDate()) || today.isAfter(n.getCloseDate()))
            throw new IllegalStateException("Window closed");
        if (appRepo.existsByApplicantIdAndVacancyId(p.getId(), v.getId()))
            throw new IllegalStateException("Already applied");
        var violations = evaluator.evaluate(p, v, n.getCloseDate());
        if (!violations.isEmpty()) throw new IneligibleException("Failed", violations);
        var app = new Application();
        app.setApplicant(p);
        app.setVacancy(v);
        app.setStatus("SUBMITTED");
        var saved = appRepo.save(app);
        return new ApplicationResponse(saved.getId(), v.getId(), v.getPostName(),
            n.getDepartment(), n.getTitle(), saved.getStatus(),
            saved.getReviewRemarks(), saved.getAppliedAt());
    }

    @Transactional(readOnly = true)
    public Page<ApplicationResponse> myApplications(String email, Pageable pageable) {
        var p = resolveProfile(email);
        return appRepo.findByApplicantId(p.getId(), pageable).map(this::toResponse);
    }

    private ApplicationResponse toResponse(Application a) {
        var v = a.getVacancy();
        var n = v.getNotification();
        return new ApplicationResponse(a.getId(), v.getId(), v.getPostName(),
            n.getDepartment(), n.getTitle(), a.getStatus(),
            a.getReviewRemarks(), a.getAppliedAt());
    }

    private ApplicantProfile resolveProfile(String email) {
        var u = userRepo.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return profRepo.findByUserId(u.getId())
            .orElseThrow(() -> new IllegalStateException("Complete profile first"));
    }

    private Vacancy resolveVacancy(Long id) {
        return vacRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Vacancy not found"));
    }
}
