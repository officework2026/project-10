package com.gov.portal.exam.dto;

import java.time.Instant;

public record BatchJobStatus(
    String jobId, String state, int processed, int total,
    Instant startedAt, Instant completedAt, String errorMessage
) {}
