package com.gov.portal.exam;

import com.gov.portal.exam.dto.AdmitCardResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/applications")
public class ApplicantAdmitCardController {
    private final AdmitCardService svc;
    public ApplicantAdmitCardController(AdmitCardService s) { this.svc = s; }

    @GetMapping("/{applicationId}/admit-card")
    @PreAuthorize("@ownershipGuard.isOwner(#applicationId) or @ownershipGuard.isAdmin()")
    public ResponseEntity<AdmitCardResponse> get(@PathVariable Long applicationId) {
        return svc.findByApplication(applicationId)
            .map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
