package com.gov.portal.result;

import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.result.repository.ResultRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
public class ObjectionWindowService {
    private final ResultRepository resultRepo;
    @Value("${app.objection.window.days:7}") private int days;

    public ObjectionWindowService(ResultRepository r) { this.resultRepo = r; }

    public boolean isOpen(Long resultId) {
        var r = resultRepo.findById(resultId)
            .orElseThrow(() -> new ResourceNotFoundException("Result not found"));
        if (r.getPublishedAt() == null) return false;
        return Instant.now().isBefore(r.getPublishedAt().plus(days, ChronoUnit.DAYS));
    }
}
