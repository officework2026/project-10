package com.gov.portal.admin;

import com.gov.portal.admin.dto.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/api/v1/admin/users")
@PreAuthorize("hasRole('SYS_ADMIN')")
public class AdminUserController {
    private final UserManagementService svc;
    public AdminUserController(UserManagementService s) { this.svc = s; }

    @GetMapping
    public Page<UserResponse> list(@PageableDefault(size = 20) Pageable p) { return svc.list(p); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse create(@Valid @RequestBody UserCreateRequest r) { return svc.create(r); }

    @PatchMapping("/{id}/roles")
    public UserResponse roles(@PathVariable Long id, @RequestBody Set<String> roles) {
        return svc.updateRoles(id, roles);
    }
}
