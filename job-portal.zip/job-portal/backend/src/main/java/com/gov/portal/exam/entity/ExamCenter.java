package com.gov.portal.exam.entity;

import com.gov.portal.recruitment.entity.RecruitmentNotification;
import jakarta.persistence.*;

@Entity
@Table(name = "exam_center")
public class ExamCenter {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "notification_id", nullable = false)
    private RecruitmentNotification notification;
    @Column(nullable = false, length = 200) private String name;
    @Column(nullable = false, length = 100) private String city;
    @Column(nullable = false) private Integer capacity;
    @Column(name = "allocated_count", nullable = false) private Integer allocatedCount = 0;
    @Version private Long version;

    public int remaining() { return capacity - allocatedCount; }
    public Long getId() { return id; }
    public RecruitmentNotification getNotification() { return notification; }
    public void setNotification(RecruitmentNotification n) { this.notification = n; }
    public String getName() { return name; }
    public void setName(String n) { this.name = n; }
    public String getCity() { return city; }
    public void setCity(String c) { this.city = c; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer c) { this.capacity = c; }
    public Integer getAllocatedCount() { return allocatedCount; }
    public void setAllocatedCount(Integer a) { this.allocatedCount = a; }
}
