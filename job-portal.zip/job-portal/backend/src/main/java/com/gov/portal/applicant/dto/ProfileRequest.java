package com.gov.portal.applicant.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public record ProfileRequest(
    @NotBlank @Size(max = 150) String fullName,
    @NotNull @Past LocalDate dob,
    @Pattern(regexp = "GEN|OBC|SC|ST|EWS") String category,
    @Pattern(regexp = "MALE|FEMALE|OTHER") String gender,
    @Valid @NotNull List<EducationEntry> education,
    List<Map<String, Object>> experience,
    @Valid @NotNull AddressEntry address
) {
    public record EducationEntry(
        @NotBlank String level,
        String board,
        @Min(1950) @Max(2030) Integer year,
        @DecimalMin("0") @DecimalMax("100") Double percentage
    ) {}
    public record AddressEntry(
        @NotBlank String line1,
        String line2,
        @NotBlank String city,
        @NotBlank String state,
        @Pattern(regexp = "^[1-9][0-9]{5}$") String pincode
    ) {}
}
