package com.gov.portal.admin.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "notification_template")
public class NotificationTemplate {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, unique = true, length = 50) private String code;
    @Column(nullable = false, length = 200) private String subject;
    @Column(nullable = false, columnDefinition = "TEXT") private String body;
    @Column(nullable = false, length = 20) private String channel;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt = Instant.now();

    public Long getId() { return id; }
    public String getCode() { return code; }
    public void setCode(String c) { this.code = c; }
    public String getSubject() { return subject; }
    public void setSubject(String s) { this.subject = s; }
    public String getBody() { return body; }
    public void setBody(String b) { this.body = b; }
    public String getChannel() { return channel; }
    public void setChannel(String c) { this.channel = c; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant t) { this.updatedAt = t; }
}
