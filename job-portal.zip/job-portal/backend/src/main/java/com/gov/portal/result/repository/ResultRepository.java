package com.gov.portal.result.repository;

import com.gov.portal.result.entity.Result;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import java.util.Optional;

public interface ResultRepository extends JpaRepository<Result, Long>, JpaSpecificationExecutor<Result> {
    Optional<Result> findByApplicationId(Long applicationId);
}
