package com.gov.portal.admin.dto;

import java.time.Instant;
import java.util.Set;

public record UserResponse(Long id, String email, String mobile, String status,
                           Set<String> roles, Instant createdAt) {}
