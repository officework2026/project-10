package com.gov.portal.audit;

import com.gov.portal.audit.entity.AuditLog;
import com.gov.portal.audit.repository.AuditLogRepository;
import com.gov.portal.user.repository.UserRepository;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Aspect
@Component
public class AuditAspect {
    private final AuditLogRepository repo;
    private final UserRepository userRepo;

    public AuditAspect(AuditLogRepository r, UserRepository u) {
        this.repo = r; this.userRepo = u;
    }

    @Around("@annotation(auditable)")
    public Object audit(ProceedingJoinPoint pjp, Auditable auditable) throws Throwable {
        Object result = pjp.proceed();
        CompletableFuture.runAsync(() -> {
            try {
                var log = new AuditLog();
                log.setAction(auditable.action());
                log.setEntity(auditable.entity());
                log.setCreatedAt(Instant.now());
                var auth = SecurityContextHolder.getContext().getAuthentication();
                if (auth != null && auth.isAuthenticated())
                    userRepo.findByEmail(auth.getName()).ifPresent(u -> log.setActorId(u.getId()));
                Object[] args = pjp.getArgs();
                if (args.length > 0 && args[0] instanceof Long id) log.setEntityId(id);
                var after = new HashMap<String, Object>();
                after.put("method", pjp.getSignature().getName());
                log.setAfterVal(after);
                repo.save(log);
            } catch (Exception ignored) {}
        });
        return result;
    }
}
