package com.gov.portal.applicant;

import com.gov.portal.applicant.dto.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/applicant")
public class ApplicantProfileController {
    private final ApplicantProfileService svc;
    public ApplicantProfileController(ApplicantProfileService s) { this.svc = s; }

    @GetMapping("/profile")
    public ResponseEntity<ProfileResponse> get(Authentication auth) {
        var p = svc.get(auth.getName());
        return p == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(p);
    }

    @PutMapping("/profile")
    public ProfileResponse save(Authentication auth, @Valid @RequestBody ProfileRequest r) {
        return svc.save(auth.getName(), r);
    }
}
