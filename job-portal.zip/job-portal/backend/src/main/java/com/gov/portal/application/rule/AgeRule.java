package com.gov.portal.application.rule;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.recruitment.entity.Vacancy;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.Period;
import java.util.Map;
import java.util.Optional;

@Component
public class AgeRule implements EligibilityRule {
    @Override
    public Optional<Violation> evaluate(ApplicantProfile p, Vacancy v, LocalDate cutoff) {
        Map<String, Object> e = v.getEligibility();
        if (e == null || p.getDob() == null) return Optional.empty();
        int age = Period.between(p.getDob(), cutoff).getYears();
        Integer min = (Integer) e.get("minAge");
        Integer max = (Integer) e.get("maxAge");
        if (min != null && age < min)
            return Optional.of(new Violation("AGE_BELOW_MIN", "Age " + age + " below minimum " + min));
        if (max != null && age > max)
            return Optional.of(new Violation("AGE_ABOVE_MAX", "Age " + age + " above maximum " + max));
        return Optional.empty();
    }
}
