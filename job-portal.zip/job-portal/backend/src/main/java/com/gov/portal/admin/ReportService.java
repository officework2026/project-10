package com.gov.portal.admin;

import com.opencsv.CSVWriter;
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class ReportService {
    @PersistenceContext private EntityManager em;

    @Transactional(readOnly = true)
    public byte[] applicationsByCategoryCsv(Long notificationId) {
        @SuppressWarnings("unchecked")
        List<Object[]> rows = em.createQuery("""
            SELECT p.category, COUNT(a)
            FROM Application a JOIN a.applicant p JOIN a.vacancy v
            WHERE v.notification.id = :nid
            GROUP BY p.category
            """).setParameter("nid", notificationId).getResultList();
        return toCsv(List.of("Category","Applications"),
            rows.stream().map(r -> new String[]{String.valueOf(r[0]), String.valueOf(r[1])}).toList());
    }

    @Transactional(readOnly = true)
    public byte[] applicationsByGenderCsv(Long notificationId) {
        @SuppressWarnings("unchecked")
        List<Object[]> rows = em.createQuery("""
            SELECT p.gender, COUNT(a)
            FROM Application a JOIN a.applicant p JOIN a.vacancy v
            WHERE v.notification.id = :nid
            GROUP BY p.gender
            """).setParameter("nid", notificationId).getResultList();
        return toCsv(List.of("Gender","Applications"),
            rows.stream().map(r -> new String[]{String.valueOf(r[0]), String.valueOf(r[1])}).toList());
    }

    @Transactional(readOnly = true)
    public byte[] feeCollectionCsv(Long notificationId) {
        @SuppressWarnings("unchecked")
        List<Object[]> rows = em.createQuery("""
            SELECT pt.status, COUNT(pt), COALESCE(SUM(pt.amount), 0)
            FROM PaymentTransaction pt JOIN pt.application a JOIN a.vacancy v
            WHERE v.notification.id = :nid
            GROUP BY pt.status
            """).setParameter("nid", notificationId).getResultList();
        return toCsv(List.of("Status","Count","Amount"),
            rows.stream().map(r -> new String[]{String.valueOf(r[0]),
                String.valueOf(r[1]), String.valueOf(r[2])}).toList());
    }

    @Transactional(readOnly = true)
    public byte[] vacancyFillRateCsv(Long notificationId) {
        @SuppressWarnings("unchecked")
        List<Object[]> rows = em.createQuery("""
            SELECT v.postName, v.totalSeats, COUNT(a)
            FROM Vacancy v LEFT JOIN Application a ON a.vacancy = v
            WHERE v.notification.id = :nid
            GROUP BY v.id, v.postName, v.totalSeats
            """).setParameter("nid", notificationId).getResultList();
        return toCsv(List.of("Post","Seats","Applications"),
            rows.stream().map(r -> new String[]{String.valueOf(r[0]),
                String.valueOf(r[1]), String.valueOf(r[2])}).toList());
    }

    @Transactional(readOnly = true)
    public byte[] applicationsByCategoryPdf(Long notificationId) {
        try {
            var out = new ByteArrayOutputStream();
            var doc = new Document();
            PdfWriter.getInstance(doc, out);
            doc.open();
            doc.add(new Paragraph("Applications by Category - Notification " + notificationId));
            doc.add(new Paragraph(" "));
            @SuppressWarnings("unchecked")
            List<Object[]> rows = em.createQuery("""
                SELECT p.category, COUNT(a)
                FROM Application a JOIN a.applicant p JOIN a.vacancy v
                WHERE v.notification.id = :nid
                GROUP BY p.category
                """).setParameter("nid", notificationId).getResultList();
            for (Object[] r : rows) doc.add(new Paragraph(r[0] + ": " + r[1]));
            doc.close();
            return out.toByteArray();
        } catch (Exception e) { throw new RuntimeException("PDF failed", e); }
    }

    private byte[] toCsv(List<String> headers, List<String[]> rows) {
        try {
            var out = new ByteArrayOutputStream();
            try (var w = new CSVWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
                w.writeNext(headers.toArray(String[]::new));
                w.writeAll(rows);
            }
            return out.toByteArray();
        } catch (Exception e) { throw new RuntimeException("CSV failed", e); }
    }
}
