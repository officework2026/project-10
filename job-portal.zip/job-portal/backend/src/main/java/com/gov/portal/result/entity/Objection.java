package com.gov.portal.result.entity;

import com.gov.portal.application.entity.Application;
import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "objection")
public class Objection {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "result_id", nullable = false)
    private Result result;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "application_id", nullable = false)
    private Application application;
    @Column(name = "question_ref", nullable = false, length = 100) private String questionRef;
    @Column(nullable = false, columnDefinition = "TEXT") private String justification;
    @Column(nullable = false, length = 20) private String status = "SUBMITTED";
    @Column(name = "admin_remarks", columnDefinition = "TEXT") private String adminRemarks;
    @Column(name = "raised_at", nullable = false, updatable = false) private Instant raisedAt = Instant.now();
    @Column(name = "resolved_at") private Instant resolvedAt;

    public Long getId() { return id; }
    public Result getResult() { return result; }
    public void setResult(Result r) { this.result = r; }
    public Application getApplication() { return application; }
    public void setApplication(Application a) { this.application = a; }
    public String getQuestionRef() { return questionRef; }
    public void setQuestionRef(String q) { this.questionRef = q; }
    public String getJustification() { return justification; }
    public void setJustification(String j) { this.justification = j; }
    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }
    public String getAdminRemarks() { return adminRemarks; }
    public void setAdminRemarks(String a) { this.adminRemarks = a; }
    public Instant getRaisedAt() { return raisedAt; }
    public Instant getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(Instant i) { this.resolvedAt = i; }
}
