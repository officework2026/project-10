package com.gov.portal.payment.gateway;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.UUID;

@Component
public class SandboxPaymentGateway implements PaymentGateway {
    @Override
    public PaymentOrder createOrder(BigDecimal amount, String receipt) {
        String id = "sandbox_" + UUID.randomUUID().toString().replace("-", "");
        return new PaymentOrder(id, "https://sandbox.payment.example/pay/" + id);
    }
    @Override
    public boolean verifyWebhookSignature(String payload, String signature) {
        return "sandbox-secret".equals(signature);
    }
}
