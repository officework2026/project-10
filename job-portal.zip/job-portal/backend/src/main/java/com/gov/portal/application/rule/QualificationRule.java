package com.gov.portal.application.rule;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.recruitment.entity.Vacancy;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class QualificationRule implements EligibilityRule {
    private static final List<String> ORDER = List.of("10TH","12TH","GRADUATION","POST_GRADUATION");

    @Override
    public Optional<Violation> evaluate(ApplicantProfile p, Vacancy v, LocalDate cutoff) {
        Map<String, Object> e = v.getEligibility();
        if (e == null) return Optional.empty();
        String required = (String) e.get("qualification");
        if (required == null) return Optional.empty();
        var edu = p.getEducation();
        if (edu == null || edu.isEmpty())
            return Optional.of(new Violation("NO_QUALIFICATION", "No education on profile"));
        int rank = ORDER.indexOf(required);
        boolean ok = edu.stream()
            .map(x -> (String) x.get("level"))
            .filter(ORDER::contains)
            .mapToInt(ORDER::indexOf).anyMatch(r -> r >= rank);
        return ok ? Optional.empty() : Optional.of(new Violation(
            "QUALIFICATION_INSUFFICIENT", "Required: " + required));
    }
}
