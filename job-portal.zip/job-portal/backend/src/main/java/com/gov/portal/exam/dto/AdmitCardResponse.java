package com.gov.portal.exam.dto;

import java.time.LocalDate;

public record AdmitCardResponse(
    Long id, Long applicationId, String rollNumber,
    String centerName, String centerCity, LocalDate examDate,
    String qrPayload, boolean pdfReady
) {}
