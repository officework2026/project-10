package com.gov.portal.review;

import com.gov.portal.review.dto.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/review")
@PreAuthorize("hasAnyRole('REVIEWER','SYS_ADMIN')")
public class ReviewController {
    private final ReviewService svc;
    public ReviewController(ReviewService s) { this.svc = s; }

    @GetMapping
    public Page<ReviewResponse> queue(@RequestParam(required = false) Long notificationId,
                                      @RequestParam(required = false) String status,
                                      @PageableDefault(size = 20, sort = "appliedAt") Pageable p) {
        return svc.queue(notificationId, status, p);
    }

    @PatchMapping("/{id}/approve")
    public ReviewResponse approve(@PathVariable Long id, @Valid @RequestBody ReviewRequest r) {
        return svc.approve(id, r);
    }

    @PatchMapping("/{id}/reject")
    public ReviewResponse reject(@PathVariable Long id, @Valid @RequestBody ReviewRequest r) {
        return svc.reject(id, r);
    }

    @PostMapping("/batch")
    public List<ReviewResponse> batch(@Valid @RequestBody BatchReviewRequest r) {
        return svc.batch(r);
    }
}
