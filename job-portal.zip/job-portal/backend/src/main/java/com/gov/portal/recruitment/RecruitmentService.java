package com.gov.portal.recruitment;

import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.recruitment.dto.*;
import com.gov.portal.recruitment.entity.RecruitmentNotification;
import com.gov.portal.recruitment.entity.Vacancy;
import com.gov.portal.recruitment.repository.NotificationRepository;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class RecruitmentService {
    private final NotificationRepository repo;
    private final UserRepository userRepo;

    public RecruitmentService(NotificationRepository r, UserRepository u) {
        this.repo = r; this.userRepo = u;
    }

    @Transactional
    public NotificationResponse createDraft(NotificationRequest req, String adminEmail) {
        Long adminId = userRepo.findByEmail(adminEmail).map(u -> u.getId()).orElse(null);
        RecruitmentNotification n = new RecruitmentNotification();
        n.setTitle(req.title());
        n.setDepartment(req.department());
        n.setDescription(req.description());
        n.setOpenDate(req.openDate());
        n.setCloseDate(req.closeDate());
        n.setFeeGeneral(req.feeGeneral());
        n.setFeeReserved(req.feeReserved());
        n.setStatus("DRAFT");
        n.setCreatedBy(adminId);

        List<Vacancy> vacancies = req.vacancies().stream().map(v -> {
            Vacancy e = new Vacancy();
            e.setNotification(n);
            e.setPostName(v.postName());
            e.setTotalSeats(v.totalSeats());
            e.setReservation(v.reservation());
            e.setEligibility(v.eligibility());
            return e;
        }).toList();
        n.setVacancies(vacancies);

        return toResponse(repo.save(n));
    }

    @Transactional
    public NotificationResponse publish(Long id) {
        var n = repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        if (!"DRAFT".equals(n.getStatus()))
            throw new IllegalStateException("Only DRAFT can be published");
        if (n.getVacancies() == null || n.getVacancies().isEmpty())
            throw new IllegalStateException("Cannot publish with no vacancies");
        n.setStatus("PUBLISHED");
        return toResponse(repo.save(n));
    }

    @Transactional(readOnly = true)
    public Page<NotificationResponse> search(String department, String keyword,
                                             LocalDate closingAfter, Pageable pageable) {
        Specification<RecruitmentNotification> spec = (root, q, cb) -> {
            var ps = new java.util.ArrayList<jakarta.persistence.criteria.Predicate>();
            ps.add(cb.equal(root.get("status"), "PUBLISHED"));
            if (department != null && !department.isBlank())
                ps.add(cb.equal(root.get("department"), department));
            if (keyword != null && !keyword.isBlank())
                ps.add(cb.like(cb.lower(root.get("title")), "%" + keyword.toLowerCase() + "%"));
            if (closingAfter != null)
                ps.add(cb.greaterThanOrEqualTo(root.get("closeDate"), closingAfter));
            return cb.and(ps.toArray(new jakarta.persistence.criteria.Predicate[0]));
        };
        return repo.findAll(spec, pageable).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public NotificationResponse get(Long id) {
        return repo.findById(id).map(this::toResponse)
            .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
    }

    private NotificationResponse toResponse(RecruitmentNotification n) {
        return new NotificationResponse(
            n.getId(), n.getTitle(), n.getDepartment(), n.getDescription(),
            n.getOpenDate(), n.getCloseDate(), n.getFeeGeneral(), n.getFeeReserved(),
            n.getStatus(),
            n.getVacancies() == null ? List.of() : n.getVacancies().stream().map(v ->
                new NotificationResponse.VacancyResponse(
                    v.getId(), v.getPostName(), v.getTotalSeats(),
                    v.getReservation(), v.getEligibility()
                )).toList()
        );
    }
}
