package com.gov.portal.result.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.Map;

public record MarksEntryRequest(
    @NotEmpty Map<String, BigDecimal> marks,
    @NotNull @DecimalMin("0.00") @DecimalMax("100.00") BigDecimal total,
    @NotNull Boolean qualified
) {}
