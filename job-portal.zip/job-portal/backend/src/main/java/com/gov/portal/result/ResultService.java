package com.gov.portal.result;

import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.result.dto.*;
import com.gov.portal.result.entity.Result;
import com.gov.portal.result.repository.ResultRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Map;

@Service
public class ResultService {
    private final ResultRepository resultRepo;
    private final ApplicationRepository appRepo;

    public ResultService(ResultRepository r, ApplicationRepository a) {
        this.resultRepo = r; this.appRepo = a;
    }

    @Transactional
    public ResultResponse enterMarks(Long applicationId, MarksEntryRequest req) {
        var app = appRepo.findById(applicationId)
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
        if (!"ELIGIBLE".equals(app.getStatus()))
            throw new IllegalStateException("Only ELIGIBLE can receive marks");
        var r = resultRepo.findByApplicationId(applicationId).orElseGet(() -> {
            var n = new Result(); n.setApplication(app); return n;
        });
        r.setMarks((Map<String, Object>) (Map<?, ?>) req.marks());
        r.setTotal(req.total());
        r.setQualified(req.qualified());
        return toResponse(resultRepo.save(r));
    }

    @Transactional
    public ResultResponse publish(Long resultId) {
        var r = resultRepo.findById(resultId)
            .orElseThrow(() -> new ResourceNotFoundException("Result not found"));
        if (r.getPublishedAt() != null)
            throw new IllegalStateException("Already published");
        r.setPublishedAt(Instant.now());
        var app = r.getApplication();
        app.setStatus("RESULT_PUBLISHED");
        appRepo.save(app);
        return toResponse(resultRepo.save(r));
    }

    @Transactional
    public int publishAll(Long notificationId) {
        Specification<Result> spec = (root, q, cb) -> cb.and(
            cb.isNull(root.get("publishedAt")),
            cb.equal(root.get("application").get("vacancy").get("notification").get("id"), notificationId));
        int count = 0;
        for (var r : resultRepo.findAll(spec)) {
            r.setPublishedAt(Instant.now());
            r.getApplication().setStatus("RESULT_PUBLISHED");
            appRepo.save(r.getApplication());
            resultRepo.save(r);
            count++;
        }
        return count;
    }

    @Transactional(readOnly = true)
    public Page<ResultResponse> list(Long notificationId, Pageable p) {
        Specification<Result> spec = (root, q, cb) -> notificationId == null ? cb.conjunction()
            : cb.equal(root.get("application").get("vacancy").get("notification").get("id"), notificationId);
        return resultRepo.findAll(spec, p).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public ResultResponse findByApplication(Long applicationId) {
        return resultRepo.findByApplicationId(applicationId)
            .map(this::toResponse)
            .orElseThrow(() -> new ResourceNotFoundException("No result"));
    }

    private ResultResponse toResponse(Result r) {
        var app = r.getApplication();
        var v = app.getVacancy();
        var n = v.getNotification();
        return new ResultResponse(r.getId(), app.getId(), v.getPostName(), n.getTitle(),
            r.getMarks(), r.getTotal(), r.getQualified(), r.getPublishedAt(), false, null);
    }
}
