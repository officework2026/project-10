package com.gov.portal.result.repository;

import com.gov.portal.result.entity.Objection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ObjectionRepository extends JpaRepository<Objection, Long> {
    Page<Objection> findByApplicationId(Long applicationId, Pageable p);
    Page<Objection> findByStatus(String status, Pageable p);
    boolean existsByResultIdAndQuestionRef(Long resultId, String questionRef);
}
