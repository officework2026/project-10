package com.gov.portal.application.dto;

import com.gov.portal.application.rule.Violation;
import java.util.List;

public record EligibilityCheckResponse(boolean eligible, List<Violation> violations) {}
