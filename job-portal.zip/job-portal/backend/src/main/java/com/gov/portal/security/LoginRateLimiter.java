package com.gov.portal.security;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class LoginRateLimiter {
    private static final int MAX = 5;
    private static final Duration WINDOW = Duration.ofMinutes(15);
    private final StringRedisTemplate redis;
    public LoginRateLimiter(StringRedisTemplate redis) { this.redis = redis; }

    public boolean tryAcquire(String key) {
        String k = "login:attempts:" + key;
        Long c = redis.opsForValue().increment(k);
        if (c != null && c == 1) redis.expire(k, WINDOW);
        return c != null && c <= MAX;
    }
    public void reset(String key) { redis.delete("login:attempts:" + key); }
}
