package com.gov.portal.result.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;

public record ResultResponse(
    Long id, Long applicationId, String postName, String notificationTitle,
    Map<String, Object> marks, BigDecimal total, Boolean qualified,
    Instant publishedAt, boolean hasObjection, String objectionStatus
) {}
