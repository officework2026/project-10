package com.gov.portal.payment.entity;

import com.gov.portal.application.entity.Application;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "payment_transaction")
public class PaymentTransaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "application_id", nullable = false, unique = true)
    private Application application;
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal amount;
    @Column(name = "gateway_ref", unique = true, length = 100) private String gatewayRef;
    @Column(nullable = false, length = 20) private String status = "PENDING";
    @Column(name = "paid_at") private Instant paidAt;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();
    @Version private Long version;

    public Long getId() { return id; }
    public Application getApplication() { return application; }
    public void setApplication(Application a) { this.application = a; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal a) { this.amount = a; }
    public String getGatewayRef() { return gatewayRef; }
    public void setGatewayRef(String g) { this.gatewayRef = g; }
    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }
    public Instant getPaidAt() { return paidAt; }
    public void setPaidAt(Instant t) { this.paidAt = t; }
}
