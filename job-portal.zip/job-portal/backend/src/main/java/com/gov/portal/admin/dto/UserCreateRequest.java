package com.gov.portal.admin.dto;

import jakarta.validation.constraints.*;
import java.util.Set;

public record UserCreateRequest(
    @NotBlank @Email String email,
    @NotBlank @Pattern(regexp = "^[6-9]\\d{9}$") String mobile,
    @NotBlank @Size(min = 8, max = 100) String password,
    @NotEmpty Set<String> roles
) {}
