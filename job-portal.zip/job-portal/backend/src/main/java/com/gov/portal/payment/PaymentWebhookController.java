package com.gov.portal.payment;

import com.gov.portal.payment.gateway.PaymentGateway;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/payments/webhook")
public class PaymentWebhookController {
    private final PaymentService svc;
    private final PaymentGateway gateway;

    public PaymentWebhookController(PaymentService s, PaymentGateway g) {
        this.svc = s; this.gateway = g;
    }

    @PostMapping
    public ResponseEntity<Void> handle(@RequestBody Map<String, String> payload,
                                       @RequestHeader(value = "X-Payment-Signature", required = false) String sig) {
        if (sig == null || !gateway.verifyWebhookSignature(payload.toString(), sig))
            return ResponseEntity.status(401).build();
        String ref = payload.get("gatewayRef");
        String status = payload.get("status");
        if (ref == null || status == null) return ResponseEntity.badRequest().build();
        svc.handleWebhook(ref, status);
        return ResponseEntity.ok().build();
    }
}
