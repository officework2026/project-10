package com.gov.portal.exam;

import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.exam.dto.AllocationResult;
import com.gov.portal.exam.entity.ExamCenter;
import com.gov.portal.exam.repository.ExamCenterRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CenterAllocationService {
    private final ApplicationRepository appRepo;
    private final ExamCenterRepository centerRepo;
    private final AdmitCardService admitCardService;

    public CenterAllocationService(ApplicationRepository a, ExamCenterRepository c, AdmitCardService s) {
        this.appRepo = a; this.centerRepo = c; this.admitCardService = s;
    }

    @Transactional
    public AllocationResult allocate(Long notificationId) {
        var eligible = appRepo.findByVacancyNotificationIdAndStatus(notificationId, "ELIGIBLE");
        if (eligible.isEmpty()) return new AllocationResult(0, 0, 0, List.of("No eligible applications"));

        Map<String, List<com.gov.portal.application.entity.Application>> byCity = eligible.stream()
            .collect(Collectors.groupingBy(app -> {
                Object city = app.getApplicant().getAddress() != null
                    ? app.getApplicant().getAddress().get("city") : null;
                return city != null ? city.toString() : "UNKNOWN";
            }));

        var centers = centerRepo.findByNotificationId(notificationId).stream()
            .filter(c -> c.remaining() > 0).collect(Collectors.toList());

        int allocated = 0;
        var warnings = new ArrayList<String>();

        for (var entry : byCity.entrySet()) {
            var city = entry.getKey();
            for (var app : entry.getValue()) {
                var target = centers.stream()
                    .filter(c -> c.remaining() > 0)
                    .filter(c -> c.getCity().equalsIgnoreCase(city))
                    .max(Comparator.comparingInt(ExamCenter::remaining))
                    .orElse(centers.stream().filter(c -> c.remaining() > 0)
                        .max(Comparator.comparingInt(ExamCenter::remaining)).orElse(null));
                if (target == null) { warnings.add("No capacity for app " + app.getId()); continue; }
                var roll = admitCardService.generateRollNumber();
                admitCardService.create(app, target, roll);
                target.setAllocatedCount(target.getAllocatedCount() + 1);
                centerRepo.save(target);
                allocated++;
            }
        }
        return new AllocationResult(eligible.size(), allocated, eligible.size() - allocated, warnings);
    }
}
