package com.gov.portal.result.dto;

import jakarta.validation.constraints.*;

public record ObjectionRequest(
    @NotBlank @Size(max = 100) String questionRef,
    @NotBlank @Size(max = 2000) String justification
) {}
