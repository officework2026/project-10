package com.gov.portal.payment;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {
    private final PaymentService svc;
    public PaymentController(PaymentService s) { this.svc = s; }

    @PostMapping("/initiate/{applicationId}")
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> initiate(@PathVariable Long applicationId,
                                        @RequestParam BigDecimal amount) {
        var tx = svc.initiate(applicationId, amount);
        return Map.of("transactionId", tx.getId(), "gatewayRef", tx.getGatewayRef(),
            "status", tx.getStatus(), "amount", tx.getAmount());
    }

    @GetMapping("/application/{applicationId}")
    public Object getByApplication(@PathVariable Long applicationId) {
        return svc.findByApplication(applicationId);
    }
}
