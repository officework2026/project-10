package com.gov.portal.admin;

import com.gov.portal.admin.entity.NotificationTemplate;
import com.gov.portal.admin.repository.NotificationTemplateRepository;
import com.gov.portal.common.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class NotificationTemplateService {
    private final NotificationTemplateRepository repo;
    public NotificationTemplateService(NotificationTemplateRepository r) { this.repo = r; }

    @Transactional(readOnly = true)
    public List<NotificationTemplate> listAll() { return repo.findAll(); }

    @Transactional
    public NotificationTemplate update(Long id, String subject, String body) {
        var t = repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Template not found"));
        t.setSubject(subject);
        t.setBody(body);
        t.setUpdatedAt(Instant.now());
        return repo.save(t);
    }
}
