package com.gov.portal.review.dto;

import java.time.Instant;

public record ReviewResponse(
    Long id, Long vacancyId, String postName,
    Long notificationId, String notificationTitle, String department,
    String status, String reviewRemarks, Instant appliedAt
) {}
