package com.gov.portal.common;

public class TooManyAttemptsException extends RuntimeException {
    public TooManyAttemptsException(String m) { super(m); }
}
