package com.gov.portal.recruitment.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public record NotificationResponse(
    Long id, String title, String department, String description,
    LocalDate openDate, LocalDate closeDate,
    BigDecimal feeGeneral, BigDecimal feeReserved, String status,
    List<VacancyResponse> vacancies
) {
    public record VacancyResponse(
        Long id, String postName, Integer totalSeats,
        Map<String, Integer> reservation, Map<String, Object> eligibility
    ) {}
}
