package com.gov.portal.exam.dto;

import java.util.List;

public record AllocationResult(int totalEligible, int allocated, int unallocated, List<String> warnings) {}
