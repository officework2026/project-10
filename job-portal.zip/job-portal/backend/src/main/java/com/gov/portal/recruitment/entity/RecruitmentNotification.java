package com.gov.portal.recruitment.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Entity
@Table(name = "recruitment_notification")
public class RecruitmentNotification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private String title;
    @Column(nullable = false, length = 150) private String department;
    @Column(columnDefinition = "TEXT") private String description;
    @Column(name = "open_date", nullable = false) private LocalDate openDate;
    @Column(name = "close_date", nullable = false) private LocalDate closeDate;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private List<Map<String, Object>> stages;
    @Column(name = "fee_general", precision = 10, scale = 2) private BigDecimal feeGeneral;
    @Column(name = "fee_reserved", precision = 10, scale = 2) private BigDecimal feeReserved;
    @Column(nullable = false, length = 20) private String status = "DRAFT";
    @Column(name = "created_by") private Long createdBy;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();
    @OneToMany(mappedBy = "notification", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Vacancy> vacancies;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String t) { this.title = t; }
    public String getDepartment() { return department; }
    public void setDepartment(String d) { this.department = d; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public LocalDate getOpenDate() { return openDate; }
    public void setOpenDate(LocalDate d) { this.openDate = d; }
    public LocalDate getCloseDate() { return closeDate; }
    public void setCloseDate(LocalDate d) { this.closeDate = d; }
    public List<Map<String, Object>> getStages() { return stages; }
    public void setStages(List<Map<String, Object>> s) { this.stages = s; }
    public BigDecimal getFeeGeneral() { return feeGeneral; }
    public void setFeeGeneral(BigDecimal b) { this.feeGeneral = b; }
    public BigDecimal getFeeReserved() { return feeReserved; }
    public void setFeeReserved(BigDecimal b) { this.feeReserved = b; }
    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long id) { this.createdBy = id; }
    public Instant getCreatedAt() { return createdAt; }
    public List<Vacancy> getVacancies() { return vacancies; }
    public void setVacancies(List<Vacancy> v) { this.vacancies = v; }
}
