package com.gov.portal.common;

public class DuplicateResourceException extends RuntimeException {
    public DuplicateResourceException(String m) { super(m); }
}
