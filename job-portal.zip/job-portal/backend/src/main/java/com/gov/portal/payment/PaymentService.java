package com.gov.portal.payment;

import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.payment.entity.PaymentTransaction;
import com.gov.portal.payment.gateway.PaymentGateway;
import com.gov.portal.payment.repository.PaymentTransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;

@Service
public class PaymentService {
    private final PaymentTransactionRepository payRepo;
    private final ApplicationRepository appRepo;
    private final PaymentGateway gateway;

    public PaymentService(PaymentTransactionRepository p, ApplicationRepository a, PaymentGateway g) {
        this.payRepo = p; this.appRepo = a; this.gateway = g;
    }

    @Transactional
    public PaymentTransaction initiate(Long applicationId, BigDecimal amount) {
        var app = appRepo.findById(applicationId)
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
        if (payRepo.findByApplicationId(applicationId).isPresent())
            throw new IllegalStateException("Payment already initiated");
        var order = gateway.createOrder(amount, "APP-" + applicationId);
        var tx = new PaymentTransaction();
        tx.setApplication(app);
        tx.setAmount(amount);
        tx.setGatewayRef(order.orderId());
        tx.setStatus("PENDING");
        return payRepo.save(tx);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleWebhook(String gatewayRef, String status) {
        var tx = payRepo.findByGatewayRef(gatewayRef)
            .orElseThrow(() -> new ResourceNotFoundException("Unknown gateway ref"));
        if ("SUCCESS".equals(tx.getStatus()) || "FAILED".equals(tx.getStatus())) return;
        tx.setStatus(status);
        if ("SUCCESS".equals(status)) {
            tx.setPaidAt(Instant.now());
            var app = tx.getApplication();
            app.setStatus("ELIGIBLE_PENDING_REVIEW");
            appRepo.save(app);
        }
        payRepo.save(tx);
    }

    @Transactional(readOnly = true)
    public PaymentTransaction findByApplication(Long id) {
        return payRepo.findByApplicationId(id)
            .orElseThrow(() -> new ResourceNotFoundException("No payment for application"));
    }
}
