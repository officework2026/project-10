package com.gov.portal.payment.gateway;

import java.math.BigDecimal;

public interface PaymentGateway {
    PaymentOrder createOrder(BigDecimal amount, String receipt);
    boolean verifyWebhookSignature(String payload, String signature);
    record PaymentOrder(String orderId, String paymentUrl) {}
}
