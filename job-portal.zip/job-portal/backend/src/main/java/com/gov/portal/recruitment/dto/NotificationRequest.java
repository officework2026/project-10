package com.gov.portal.recruitment.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public record NotificationRequest(
    @NotBlank @Size(max = 255) String title,
    @NotBlank @Size(max = 150) String department,
    String description,
    @NotNull @FutureOrPresent LocalDate openDate,
    @NotNull @Future LocalDate closeDate,
    @Valid @NotEmpty List<VacancyEntry> vacancies,
    List<Map<String, Object>> stages,
    BigDecimal feeGeneral,
    BigDecimal feeReserved
) {
    public record VacancyEntry(
        @NotBlank String postName,
        @NotNull @Min(1) Integer totalSeats,
        @NotNull Map<String, Integer> reservation,
        @NotNull Map<String, Object> eligibility
    ) {}
}
