package com.gov.portal.result;

import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.result.dto.*;
import com.gov.portal.result.entity.Objection;
import com.gov.portal.result.repository.ObjectionRepository;
import com.gov.portal.result.repository.ResultRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class ObjectionService {
    private final ObjectionRepository objRepo;
    private final ResultRepository resultRepo;
    private final ObjectionWindowService window;

    public ObjectionService(ObjectionRepository o, ResultRepository r, ObjectionWindowService w) {
        this.objRepo = o; this.resultRepo = r; this.window = w;
    }

    @Transactional
    public ObjectionResponse raise(Long applicationId, ObjectionRequest req) {
        var result = resultRepo.findByApplicationId(applicationId)
            .orElseThrow(() -> new ResourceNotFoundException("No result"));
        if (result.getPublishedAt() == null) throw new IllegalStateException("Not published");
        if (!window.isOpen(result.getId())) throw new IllegalStateException("Window closed");
        if (objRepo.existsByResultIdAndQuestionRef(result.getId(), req.questionRef()))
            throw new IllegalStateException("Already raised for this question");
        var obj = new Objection();
        obj.setResult(result);
        obj.setApplication(result.getApplication());
        obj.setQuestionRef(req.questionRef());
        obj.setJustification(req.justification());
        obj.setStatus("SUBMITTED");
        return toResponse(objRepo.save(obj));
    }

    @Transactional(readOnly = true)
    public Page<ObjectionResponse> listForApp(Long applicationId, Pageable p) {
        return objRepo.findByApplicationId(applicationId, p).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public Page<ObjectionResponse> adminQueue(String status, Pageable p) {
        return objRepo.findByStatus(status == null ? "SUBMITTED" : status, p).map(this::toResponse);
    }

    @Transactional
    public ObjectionResponse resolve(Long id, String status, String remarks) {
        if (!"ACCEPTED".equals(status) && !"REJECTED".equals(status))
            throw new IllegalArgumentException("Status must be ACCEPTED/REJECTED");
        var o = objRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Not found"));
        o.setStatus(status);
        o.setAdminRemarks(remarks);
        o.setResolvedAt(Instant.now());
        return toResponse(objRepo.save(o));
    }

    private ObjectionResponse toResponse(Objection o) {
        return new ObjectionResponse(o.getId(), o.getResult().getId(),
            o.getQuestionRef(), o.getJustification(), o.getStatus(),
            o.getAdminRemarks(), o.getRaisedAt(), o.getResolvedAt());
    }
}
