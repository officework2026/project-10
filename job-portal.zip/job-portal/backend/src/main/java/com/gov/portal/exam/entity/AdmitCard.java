package com.gov.portal.exam.entity;

import com.gov.portal.application.entity.Application;
import jakarta.persistence.*;

import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "admit_card")
public class AdmitCard {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "application_id", nullable = false, unique = true)
    private Application application;
    @Column(name = "roll_number", nullable = false, unique = true, length = 30)
    private String rollNumber;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "exam_center_id", nullable = false)
    private ExamCenter examCenter;
    @Column(name = "exam_date", nullable = false) private LocalDate examDate;
    @Column(name = "qr_payload", nullable = false, columnDefinition = "TEXT") private String qrPayload;
    @Column(name = "object_key", length = 500) private String objectKey;
    @Column(name = "generated_at", nullable = false, updatable = false) private Instant generatedAt = Instant.now();

    public Long getId() { return id; }
    public Application getApplication() { return application; }
    public void setApplication(Application a) { this.application = a; }
    public String getRollNumber() { return rollNumber; }
    public void setRollNumber(String r) { this.rollNumber = r; }
    public ExamCenter getExamCenter() { return examCenter; }
    public void setExamCenter(ExamCenter e) { this.examCenter = e; }
    public LocalDate getExamDate() { return examDate; }
    public void setExamDate(LocalDate d) { this.examDate = d; }
    public String getQrPayload() { return qrPayload; }
    public void setQrPayload(String q) { this.qrPayload = q; }
    public String getObjectKey() { return objectKey; }
    public void setObjectKey(String o) { this.objectKey = o; }
}
