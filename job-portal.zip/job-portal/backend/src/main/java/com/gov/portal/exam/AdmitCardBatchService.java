package com.gov.portal.exam;

import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.exam.entity.AdmitCard;
import com.gov.portal.exam.repository.AdmitCardRepository;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.UUID;

@Service
public class AdmitCardBatchService {
    private final AdmitCardRepository admitRepo;
    private final ApplicationRepository appRepo;
    private final BatchJobStatusService status;
    private final MinioClient minio;

    @Value("${app.storage.bucket}") private String bucket;

    public AdmitCardBatchService(AdmitCardRepository a, ApplicationRepository p,
                                 BatchJobStatusService s, MinioClient m) {
        this.admitRepo = a; this.appRepo = p; this.status = s; this.minio = m;
    }

    @Async
    public void generateBatch(Long notificationId, String jobId) {
        try {
            var apps = appRepo.findByVacancyNotificationIdAndStatus(notificationId, "ELIGIBLE");
            status.start(jobId, apps.size());
            int processed = 0;
            for (var app : apps) {
                try {
                    var card = admitRepo.findByApplicationId(app.getId()).orElse(null);
                    if (card == null) continue;
                    byte[] pdf = render(card);
                    String key = "admit_cards/%d/%s.pdf".formatted(app.getId(),
                        UUID.randomUUID().toString().substring(0, 8));
                    minio.putObject(PutObjectArgs.builder()
                        .bucket(bucket).object(key)
                        .stream(new ByteArrayInputStream(pdf), pdf.length, -1)
                        .contentType("application/pdf").build());
                    card.setObjectKey(key);
                    admitRepo.save(card);
                    processed++;
                    if (processed % 100 == 0) status.progress(jobId, processed);
                } catch (Exception ignored) {}
            }
            status.complete(jobId, processed, apps.size());
        } catch (Exception e) {
            status.fail(jobId, e.getMessage());
        }
    }

    private byte[] render(AdmitCard c) throws DocumentException {
        var out = new ByteArrayOutputStream();
        var doc = new Document();
        PdfWriter.getInstance(doc, out);
        doc.open();
        doc.add(new Paragraph("GOVERNMENT JOB PORTAL",
            FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
        doc.add(new Paragraph("ADMIT CARD"));
        doc.add(Chunk.NEWLINE);
        var app = c.getApplication();
        doc.add(new Paragraph("Roll Number: " + c.getRollNumber()));
        doc.add(new Paragraph("Name: " + app.getApplicant().getFullName()));
        doc.add(new Paragraph("Post: " + app.getVacancy().getPostName()));
        doc.add(new Paragraph("Center: " + c.getExamCenter().getName()
            + ", " + c.getExamCenter().getCity()));
        doc.add(new Paragraph("Date: " + c.getExamDate()));
        doc.add(new Paragraph("QR: " + c.getQrPayload(),
            FontFactory.getFont(FontFactory.COURIER, 8)));
        doc.close();
        return out.toByteArray();
    }
}
