package com.gov.portal.application.rule;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.recruitment.entity.Vacancy;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class CategoryRule implements EligibilityRule {
    @Override
    public Optional<Violation> evaluate(ApplicantProfile p, Vacancy v, LocalDate cutoff) {
        Map<String, Object> e = v.getEligibility();
        if (e == null) return Optional.empty();
        Object allowed = e.get("allowedCategories");
        if (!(allowed instanceof List<?> list) || list.isEmpty()) return Optional.empty();
        if (p.getCategory() == null || !list.contains(p.getCategory()))
            return Optional.of(new Violation("CATEGORY_NOT_ALLOWED",
                "Restricted to: " + list));
        return Optional.empty();
    }
}
