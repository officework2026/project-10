package com.gov.portal.audit.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.Instant;
import java.util.Map;

@Entity
@Table(name = "audit_log")
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "actor_id") private Long actorId;
    @Column(nullable = false, length = 100) private String action;
    @Column(nullable = false, length = 100) private String entity;
    @Column(name = "entity_id") private Long entityId;
    @JdbcTypeCode(SqlTypes.JSON) @Column(name = "before_val", columnDefinition = "jsonb")
    private Map<String, Object> beforeVal;
    @JdbcTypeCode(SqlTypes.JSON) @Column(name = "after_val", columnDefinition = "jsonb")
    private Map<String, Object> afterVal;
    @Column(name = "ip_address", length = 45) private String ipAddress;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();

    public Long getId() { return id; }
    public Long getActorId() { return actorId; }
    public void setActorId(Long a) { this.actorId = a; }
    public String getAction() { return action; }
    public void setAction(String a) { this.action = a; }
    public String getEntity() { return entity; }
    public void setEntity(String e) { this.entity = e; }
    public Long getEntityId() { return entityId; }
    public void setEntityId(Long e) { this.entityId = e; }
    public Map<String, Object> getBeforeVal() { return beforeVal; }
    public void setBeforeVal(Map<String, Object> v) { this.beforeVal = v; }
    public Map<String, Object> getAfterVal() { return afterVal; }
    public void setAfterVal(Map<String, Object> v) { this.afterVal = v; }
    public Instant getCreatedAt() { return createdAt; }
}
