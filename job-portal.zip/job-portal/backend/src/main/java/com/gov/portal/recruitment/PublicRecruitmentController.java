package com.gov.portal.recruitment;

import com.gov.portal.recruitment.dto.NotificationResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/notifications")
public class PublicRecruitmentController {
    private final RecruitmentService svc;
    public PublicRecruitmentController(RecruitmentService s) { this.svc = s; }

    @GetMapping
    public Page<NotificationResponse> list(
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) LocalDate closingAfter,
            @PageableDefault(size = 20, sort = "closeDate") Pageable pageable) {
        return svc.search(department, keyword, closingAfter, pageable);
    }

    @GetMapping("/{id}")
    public NotificationResponse get(@PathVariable Long id) { return svc.get(id); }
}
