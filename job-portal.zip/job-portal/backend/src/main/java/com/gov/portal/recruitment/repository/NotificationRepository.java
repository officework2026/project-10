package com.gov.portal.recruitment.repository;

import com.gov.portal.recruitment.entity.RecruitmentNotification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface NotificationRepository extends JpaRepository<RecruitmentNotification, Long>,
        JpaSpecificationExecutor<RecruitmentNotification> {}
