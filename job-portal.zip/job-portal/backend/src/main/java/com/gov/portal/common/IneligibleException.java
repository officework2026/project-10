package com.gov.portal.common;

import com.gov.portal.application.rule.Violation;
import java.util.List;

public class IneligibleException extends RuntimeException {
    private final List<Violation> violations;
    public IneligibleException(String m, List<Violation> v) { super(m); this.violations = v; }
    public List<Violation> getViolations() { return violations; }
}
