package com.gov.portal.application.repository;

import com.gov.portal.application.entity.Application;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface ApplicationRepository extends JpaRepository<Application, Long>,
        JpaSpecificationExecutor<Application> {
    Optional<Application> findByApplicantIdAndVacancyId(Long applicantId, Long vacancyId);
    boolean existsByApplicantIdAndVacancyId(Long applicantId, Long vacancyId);
    Page<Application> findByApplicantId(Long applicantId, Pageable pageable);
    List<Application> findByVacancyNotificationIdAndStatus(Long notificationId, String status);
}
