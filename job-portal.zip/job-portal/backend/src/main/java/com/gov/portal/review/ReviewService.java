package com.gov.portal.review;

import com.gov.portal.application.entity.Application;
import com.gov.portal.application.repository.ApplicationRepository;
import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.review.dto.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
public class ReviewService {
    private final ApplicationRepository appRepo;
    public ReviewService(ApplicationRepository a) { this.appRepo = a; }

    @Transactional(readOnly = true)
    public Page<ReviewResponse> queue(Long notificationId, String status, Pageable p) {
        Specification<Application> spec = (root, q, cb) -> {
            var ps = new java.util.ArrayList<jakarta.persistence.criteria.Predicate>();
            if (notificationId != null)
                ps.add(cb.equal(root.get("vacancy").get("notification").get("id"), notificationId));
            ps.add(cb.equal(root.get("status"),
                (status == null || status.isBlank()) ? "ELIGIBLE_PENDING_REVIEW" : status));
            return cb.and(ps.toArray(new jakarta.persistence.criteria.Predicate[0]));
        };
        return appRepo.findAll(spec, p).map(this::toResponse);
    }

    @Transactional
    public ReviewResponse approve(Long id, ReviewRequest r) {
        var a = find(id);
        if (!"ELIGIBLE_PENDING_REVIEW".equals(a.getStatus()))
            throw new IllegalStateException("Only pending review can be approved");
        a.setStatus("ELIGIBLE");
        a.setReviewRemarks(r.remarks());
        return toResponse(appRepo.save(a));
    }

    @Transactional
    public ReviewResponse reject(Long id, ReviewRequest r) {
        var a = find(id);
        if (!"ELIGIBLE_PENDING_REVIEW".equals(a.getStatus()))
            throw new IllegalStateException("Only pending review can be rejected");
        a.setStatus("REJECTED");
        a.setReviewRemarks(r.remarks());
        return toResponse(appRepo.save(a));
    }

    @Transactional
    public List<ReviewResponse> batch(BatchReviewRequest r) {
        return r.applicationIds().stream().map(id -> {
            var a = appRepo.findById(id).orElse(null);
            if (a == null || !"ELIGIBLE_PENDING_REVIEW".equals(a.getStatus())) return null;
            a.setStatus("ELIGIBLE".equals(r.targetStatus()) ? "ELIGIBLE" : "REJECTED");
            a.setReviewRemarks(r.remarks());
            return toResponse(appRepo.save(a));
        }).filter(Objects::nonNull).toList();
    }

    private Application find(Long id) {
        return appRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
    }

    private ReviewResponse toResponse(Application a) {
        var v = a.getVacancy(); var n = v.getNotification();
        return new ReviewResponse(a.getId(), v.getId(), v.getPostName(),
            n.getId(), n.getTitle(), n.getDepartment(),
            a.getStatus(), a.getReviewRemarks(), a.getAppliedAt());
    }
}
