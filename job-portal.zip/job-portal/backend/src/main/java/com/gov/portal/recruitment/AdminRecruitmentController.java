package com.gov.portal.recruitment;

import com.gov.portal.recruitment.dto.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/notifications")
@PreAuthorize("hasAnyRole('SYS_ADMIN','REVIEWER')")
public class AdminRecruitmentController {
    private final RecruitmentService svc;
    public AdminRecruitmentController(RecruitmentService s) { this.svc = s; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public NotificationResponse create(@Valid @RequestBody NotificationRequest r, Authentication a) {
        return svc.createDraft(r, a.getName());
    }

    @PostMapping("/{id}/publish")
    public NotificationResponse publish(@PathVariable Long id) { return svc.publish(id); }
}
