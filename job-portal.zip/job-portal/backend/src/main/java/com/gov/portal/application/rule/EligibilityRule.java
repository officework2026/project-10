package com.gov.portal.application.rule;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.recruitment.entity.Vacancy;

import java.time.LocalDate;
import java.util.Optional;

public interface EligibilityRule {
    Optional<Violation> evaluate(ApplicantProfile profile, Vacancy vacancy, LocalDate cutoff);
}
