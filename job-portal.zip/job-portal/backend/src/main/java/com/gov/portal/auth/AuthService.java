package com.gov.portal.auth;

import com.gov.portal.auth.dto.*;
import com.gov.portal.common.DuplicateResourceException;
import com.gov.portal.common.TooManyAttemptsException;
import com.gov.portal.security.JwtService;
import com.gov.portal.security.LoginRateLimiter;
import com.gov.portal.user.entity.Role;
import com.gov.portal.user.entity.User;
import com.gov.portal.user.repository.RoleRepository;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
public class AuthService {

    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final AuthenticationManager authManager;
    private final UserDetailsService uds;
    private final LoginRateLimiter rateLimiter;

    public AuthService(UserRepository userRepo, RoleRepository roleRepo,
                       PasswordEncoder encoder, JwtService jwt,
                       AuthenticationManager authManager, UserDetailsService uds,
                       LoginRateLimiter rateLimiter) {
        this.userRepo = userRepo; this.roleRepo = roleRepo; this.encoder = encoder;
        this.jwt = jwt; this.authManager = authManager; this.uds = uds;
        this.rateLimiter = rateLimiter;
    }

    @Transactional
    public void register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.email()))
            throw new DuplicateResourceException("Email already registered");
        if (userRepo.existsByMobile(req.mobile()))
            throw new DuplicateResourceException("Mobile already registered");
        Role r = roleRepo.findByName("APPLICANT")
            .orElseThrow(() -> new IllegalStateException("APPLICANT role missing"));
        User u = new User();
        u.setEmail(req.email());
        u.setMobile(req.mobile());
        u.setPasswordHash(encoder.encode(req.password()));
        u.setRoles(Set.of(r));
        userRepo.save(u);
    }

    public AuthResponse login(LoginRequest req, String ip) {
        String key = req.email() + ":" + ip;
        if (!rateLimiter.tryAcquire(key))
            throw new TooManyAttemptsException("Too many attempts. Try again in 15 minutes.");
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        rateLimiter.reset(key);
        var ud = uds.loadUserByUsername(req.email());
        return new AuthResponse(jwt.generateAccessToken(ud), null);
    }
}
