package com.gov.portal.result.entity;

import com.gov.portal.application.entity.Application;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;

@Entity
@Table(name = "result")
public class Result {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(fetch = FetchType.LAZY) @JoinColumn(name = "application_id", nullable = false, unique = true)
    private Application application;
    @JdbcTypeCode(SqlTypes.JSON) @Column(nullable = false, columnDefinition = "jsonb")
    private Map<String, Object> marks;
    @Column(nullable = false, precision = 6, scale = 2) private BigDecimal total;
    @Column(nullable = false) private Boolean qualified;
    @Column(name = "published_at") private Instant publishedAt;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();
    @Version private Long version;

    public Long getId() { return id; }
    public Application getApplication() { return application; }
    public void setApplication(Application a) { this.application = a; }
    public Map<String, Object> getMarks() { return marks; }
    public void setMarks(Map<String, Object> m) { this.marks = m; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal t) { this.total = t; }
    public Boolean getQualified() { return qualified; }
    public void setQualified(Boolean q) { this.qualified = q; }
    public Instant getPublishedAt() { return publishedAt; }
    public void setPublishedAt(Instant t) { this.publishedAt = t; }
}
