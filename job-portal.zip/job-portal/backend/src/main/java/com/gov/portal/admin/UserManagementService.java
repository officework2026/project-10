package com.gov.portal.admin;

import com.gov.portal.admin.dto.*;
import com.gov.portal.common.DuplicateResourceException;
import com.gov.portal.common.ResourceNotFoundException;
import com.gov.portal.user.entity.Role;
import com.gov.portal.user.entity.User;
import com.gov.portal.user.repository.RoleRepository;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserManagementService {
    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final PasswordEncoder encoder;

    public UserManagementService(UserRepository u, RoleRepository r, PasswordEncoder e) {
        this.userRepo = u; this.roleRepo = r; this.encoder = e;
    }

    @Transactional(readOnly = true)
    public Page<UserResponse> list(Pageable p) { return userRepo.findAll(p).map(this::toResponse); }

    @Transactional
    public UserResponse create(UserCreateRequest req) {
        if (userRepo.existsByEmail(req.email())) throw new DuplicateResourceException("Email exists");
        if (userRepo.existsByMobile(req.mobile())) throw new DuplicateResourceException("Mobile exists");
        var roles = req.roles().stream().map(name -> roleRepo.findByName(name)
            .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + name)))
            .collect(Collectors.toSet());
        var u = new User();
        u.setEmail(req.email());
        u.setMobile(req.mobile());
        u.setPasswordHash(encoder.encode(req.password()));
        u.setRoles(roles);
        return toResponse(userRepo.save(u));
    }

    @Transactional
    public UserResponse updateRoles(Long id, Set<String> names) {
        var u = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        var roles = names.stream().map(n -> roleRepo.findByName(n)
            .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + n)))
            .collect(Collectors.toSet());
        u.setRoles(roles);
        return toResponse(userRepo.save(u));
    }

    private UserResponse toResponse(User u) {
        return new UserResponse(u.getId(), u.getEmail(), u.getMobile(), u.getStatus(),
            u.getRoles().stream().map(Role::getName).collect(Collectors.toSet()), u.getCreatedAt());
    }
}
