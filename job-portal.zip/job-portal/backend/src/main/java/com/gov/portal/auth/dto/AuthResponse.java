package com.gov.portal.auth.dto;

public record AuthResponse(String accessToken, String refreshToken, String tokenType, long expiresIn) {
    public AuthResponse(String access, String refresh) { this(access, refresh, "Bearer", 900); }
}
