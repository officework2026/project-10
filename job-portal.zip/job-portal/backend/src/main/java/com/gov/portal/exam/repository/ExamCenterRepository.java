package com.gov.portal.exam.repository;

import com.gov.portal.exam.entity.ExamCenter;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ExamCenterRepository extends JpaRepository<ExamCenter, Long> {
    List<ExamCenter> findByNotificationId(Long notificationId);
}
