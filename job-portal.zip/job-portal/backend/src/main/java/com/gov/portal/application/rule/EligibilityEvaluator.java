package com.gov.portal.application.rule;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.recruitment.entity.Vacancy;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class EligibilityEvaluator {
    private final List<EligibilityRule> rules;
    public EligibilityEvaluator(List<EligibilityRule> rules) { this.rules = rules; }

    public List<Violation> evaluate(ApplicantProfile p, Vacancy v, LocalDate cutoff) {
        return rules.stream()
            .map(r -> r.evaluate(p, v, cutoff))
            .filter(Optional::isPresent).map(Optional::get).toList();
    }
}
