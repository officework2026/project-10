package com.gov.portal.recruitment.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.Map;

@Entity
@Table(name = "vacancy")
public class Vacancy {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "notification_id", nullable = false)
    private RecruitmentNotification notification;
    @Column(name = "post_name", nullable = false, length = 150) private String postName;
    @Column(name = "total_seats", nullable = false) private Integer totalSeats;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb", nullable = false)
    private Map<String, Integer> reservation;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb", nullable = false)
    private Map<String, Object> eligibility;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public RecruitmentNotification getNotification() { return notification; }
    public void setNotification(RecruitmentNotification n) { this.notification = n; }
    public String getPostName() { return postName; }
    public void setPostName(String p) { this.postName = p; }
    public Integer getTotalSeats() { return totalSeats; }
    public void setTotalSeats(Integer t) { this.totalSeats = t; }
    public Map<String, Integer> getReservation() { return reservation; }
    public void setReservation(Map<String, Integer> r) { this.reservation = r; }
    public Map<String, Object> getEligibility() { return eligibility; }
    public void setEligibility(Map<String, Object> e) { this.eligibility = e; }
}
