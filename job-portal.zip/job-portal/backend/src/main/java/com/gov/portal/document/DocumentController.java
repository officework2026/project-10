package com.gov.portal.document;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/applications/{applicationId}/documents")
public class DocumentController {
    private final DocumentService svc;
    public DocumentController(DocumentService s) { this.svc = s; }

    @PostMapping("/presign")
    @PreAuthorize("@ownershipGuard.isOwner(#applicationId) or @ownershipGuard.isAdmin()")
    public Map<String, String> presign(@PathVariable Long applicationId, @RequestParam String documentType) {
        String[] parts = svc.presign(applicationId, documentType).split("\\|");
        return Map.of("uploadUrl", parts[0], "objectKey", parts[1]);
    }

    @PostMapping("/confirm")
    @PreAuthorize("@ownershipGuard.isOwner(#applicationId) or @ownershipGuard.isAdmin()")
    public Map<String, Object> confirm(@PathVariable Long applicationId,
                                       @RequestParam String documentType,
                                       @RequestParam String objectKey,
                                       @RequestParam String originalName,
                                       @RequestParam String contentType,
                                       @RequestParam Long fileSize) {
        var d = svc.confirm(applicationId, documentType, objectKey, originalName, contentType, fileSize);
        return Map.of("documentId", d.getId(), "status", "UPLOADED");
    }
}
