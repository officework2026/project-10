package com.gov.portal.audit;

import com.gov.portal.audit.entity.AuditLog;
import com.gov.portal.audit.repository.AuditLogRepository;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/audit-logs")
@PreAuthorize("hasRole('SYS_ADMIN')")
public class AuditController {
    private final AuditLogRepository repo;
    public AuditController(AuditLogRepository r) { this.repo = r; }

    @GetMapping
    public Page<AuditLog> list(@RequestParam(required = false) Long actorId,
                               @RequestParam(required = false) String entity,
                               @RequestParam(required = false) String action,
                               @PageableDefault(size = 50, sort = "createdAt", direction = Sort.Direction.DESC) Pageable p) {
        Specification<AuditLog> spec = (root, q, cb) -> {
            var ps = new java.util.ArrayList<jakarta.persistence.criteria.Predicate>();
            if (actorId != null) ps.add(cb.equal(root.get("actorId"), actorId));
            if (entity != null) ps.add(cb.equal(root.get("entity"), entity));
            if (action != null) ps.add(cb.equal(root.get("action"), action));
            return cb.and(ps.toArray(new jakarta.persistence.criteria.Predicate[0]));
        };
        return repo.findAll(spec, p);
    }
}
