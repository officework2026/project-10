package com.gov.portal.admin;

import com.gov.portal.admin.SystemConfigService.ConfigItem;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/config")
@PreAuthorize("hasRole('SYS_ADMIN')")
public class AdminConfigController {
    private final SystemConfigService svc;
    private final UserRepository userRepo;

    public AdminConfigController(SystemConfigService s, UserRepository u) {
        this.svc = s; this.userRepo = u;
    }

    @GetMapping
    public List<ConfigItem> list() { return svc.listAll(); }

    @PutMapping("/{key}")
    public ConfigItem update(@PathVariable String key, @RequestParam String value, Authentication a) {
        Long adminId = userRepo.findByEmail(a.getName()).map(u -> u.getId()).orElse(null);
        return svc.update(key, value, adminId);
    }
}
