package com.gov.portal.result;

import com.gov.portal.result.dto.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/applications/{applicationId}")
public class ApplicantResultController {
    private final ResultService resultSvc;
    private final ObjectionService objSvc;

    public ApplicantResultController(ResultService r, ObjectionService o) {
        this.resultSvc = r; this.objSvc = o;
    }

    @GetMapping("/result")
    @PreAuthorize("@ownershipGuard.isOwner(#applicationId) or @ownershipGuard.isAdmin()")
    public ResultResponse getResult(@PathVariable Long applicationId) {
        return resultSvc.findByApplication(applicationId);
    }

    @PostMapping("/objections")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("@ownershipGuard.isOwner(#applicationId) or @ownershipGuard.isAdmin()")
    public ObjectionResponse raise(@PathVariable Long applicationId, @Valid @RequestBody ObjectionRequest r) {
        return objSvc.raise(applicationId, r);
    }

    @GetMapping("/objections")
    @PreAuthorize("@ownershipGuard.isOwner(#applicationId) or @ownershipGuard.isAdmin()")
    public Page<ObjectionResponse> myObjections(@PathVariable Long applicationId,
                                                @PageableDefault(size = 20) Pageable p) {
        return objSvc.listForApp(applicationId, p);
    }
}
