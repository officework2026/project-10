package com.gov.portal.applicant.dto;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public record ProfileResponse(
    Long id, String fullName, LocalDate dob, String category, String gender,
    List<Map<String, Object>> education, List<Map<String, Object>> experience,
    Map<String, Object> address, boolean otrCompleted
) {}
