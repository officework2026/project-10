package com.gov.portal.config;

import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.applicant.repository.ApplicantProfileRepository;
import com.gov.portal.recruitment.entity.RecruitmentNotification;
import com.gov.portal.recruitment.entity.Vacancy;
import com.gov.portal.recruitment.repository.NotificationRepository;
import com.gov.portal.user.entity.Role;
import com.gov.portal.user.entity.User;
import com.gov.portal.user.repository.RoleRepository;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Profile("dev")
@Component
public class DevDataSeeder implements CommandLineRunner {
    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final ApplicantProfileRepository profileRepo;
    private final NotificationRepository notifRepo;
    private final PasswordEncoder encoder;

    public DevDataSeeder(UserRepository u, RoleRepository r,
                         ApplicantProfileRepository p, NotificationRepository n,
                         PasswordEncoder e) {
        this.userRepo = u; this.roleRepo = r;
        this.profileRepo = p; this.notifRepo = n; this.encoder = e;
    }

    @Override
    public void run(String... args) {
        if (userRepo.count() > 0) return;
        String hash = encoder.encode("password123");

        var admin = create("admin@test.com", "9000000001", hash, "SYS_ADMIN");
        var reviewer = create("reviewer@test.com", "9000000002", hash, "REVIEWER");
        var exam = create("exam@test.com", "9000000003", hash, "EXAM_COORD");
        var applicant = create("applicant@test.com", "9000000004", hash, "APPLICANT");

        var profile = new ApplicantProfile();
        profile.setUser(applicant);
        profile.setFullName("Test Applicant");
        profile.setDob(LocalDate.of(1995, 6, 15));
        profile.setCategory("OBC");
        profile.setGender("MALE");
        profile.setEducation(List.of(Map.of("level","GRADUATION","board","State University",
            "year",2016,"percentage",78.5)));
        profile.setAddress(Map.of("line1","12 MG Road","city","Mumbai","state","MH","pincode","400001"));
        profile.setOtrCompleted(true);
        profileRepo.save(profile);

        var notif = new RecruitmentNotification();
        notif.setTitle("SSC CGL 2026");
        notif.setDepartment("Staff Selection Commission");
        notif.setDescription("Combined Graduate Level Examination 2026");
        notif.setOpenDate(LocalDate.now().minusDays(1));
        notif.setCloseDate(LocalDate.now().plusDays(30));
        notif.setFeeGeneral(new BigDecimal("500.00"));
        notif.setFeeReserved(new BigDecimal("250.00"));
        notif.setStatus("PUBLISHED");
        notif.setCreatedBy(admin.getId());

        var vacancy = new Vacancy();
        vacancy.setNotification(notif);
        vacancy.setPostName("Assistant Section Officer");
        vacancy.setTotalSeats(50);
        vacancy.setReservation(Map.of("GEN",25,"OBC",13,"SC",7,"ST",3,"EWS",2));
        vacancy.setEligibility(Map.of("minAge",18,"maxAge",32,"qualification","GRADUATION"));
        notif.setVacancies(List.of(vacancy));
        notifRepo.save(notif);

        System.out.println("Dev seed loaded. Users: admin/reviewer/exam/applicant@test.com — password123");
    }

    private User create(String email, String mobile, String hash, String roleName) {
        var role = roleRepo.findByName(roleName)
            .orElseThrow(() -> new IllegalStateException("Missing role: " + roleName));
        var u = new User();
        u.setEmail(email);
        u.setMobile(mobile);
        u.setPasswordHash(hash);
        u.setRoles(Set.of(role));
        return userRepo.save(u);
    }
}
