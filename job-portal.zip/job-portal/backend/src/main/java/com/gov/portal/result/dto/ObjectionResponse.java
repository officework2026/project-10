package com.gov.portal.result.dto;

import java.time.Instant;

public record ObjectionResponse(
    Long id, Long resultId, String questionRef, String justification,
    String status, String adminRemarks, Instant raisedAt, Instant resolvedAt
) {}
