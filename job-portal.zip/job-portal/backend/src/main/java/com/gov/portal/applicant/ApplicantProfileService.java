package com.gov.portal.applicant;

import com.gov.portal.applicant.dto.*;
import com.gov.portal.applicant.entity.ApplicantProfile;
import com.gov.portal.applicant.repository.ApplicantProfileRepository;
import com.gov.portal.user.entity.User;
import com.gov.portal.user.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
public class ApplicantProfileService {
    private final ApplicantProfileRepository profileRepo;
    private final UserRepository userRepo;

    public ApplicantProfileService(ApplicantProfileRepository p, UserRepository u) {
        this.profileRepo = p; this.userRepo = u;
    }

    @Transactional
    public ProfileResponse save(String email, ProfileRequest r) {
        User u = userRepo.findByEmail(email)
            .orElseThrow(() -> new IllegalStateException("User not found"));
        ApplicantProfile p = profileRepo.findByUserId(u.getId()).orElseGet(() -> {
            var np = new ApplicantProfile(); np.setUser(u); return np;
        });
        p.setFullName(r.fullName());
        p.setDob(r.dob());
        p.setCategory(r.category());
        p.setGender(r.gender());
        p.setEducation(r.education().stream().map(e -> Map.<String, Object>of(
            "level", e.level(),
            "board", e.board() == null ? "" : e.board(),
            "year", e.year() == null ? 0 : e.year(),
            "percentage", e.percentage() == null ? 0.0 : e.percentage()
        )).toList());
        p.setExperience(r.experience());
        p.setAddress(Map.of(
            "line1", r.address().line1(),
            "line2", r.address().line2() == null ? "" : r.address().line2(),
            "city", r.address().city(),
            "state", r.address().state(),
            "pincode", r.address().pincode()
        ));
        p.setOtrCompleted(p.getFullName() != null && p.getDob() != null
            && p.getEducation() != null && !p.getEducation().isEmpty()
            && p.getAddress() != null);
        p.setUpdatedAt(Instant.now());
        return toResponse(profileRepo.save(p));
    }

    @Transactional(readOnly = true)
    public ProfileResponse get(String email) {
        User u = userRepo.findByEmail(email)
            .orElseThrow(() -> new IllegalStateException("User not found"));
        return profileRepo.findByUserId(u.getId()).map(this::toResponse).orElse(null);
    }

    private ProfileResponse toResponse(ApplicantProfile p) {
        return new ProfileResponse(p.getId(), p.getFullName(), p.getDob(),
            p.getCategory(), p.getGender(), p.getEducation(), p.getExperience(),
            p.getAddress(), p.isOtrCompleted());
    }
}
