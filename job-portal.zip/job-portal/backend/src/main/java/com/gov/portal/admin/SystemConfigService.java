package com.gov.portal.admin;

import com.gov.portal.admin.entity.SystemConfig;
import com.gov.portal.admin.repository.SystemConfigRepository;
import com.gov.portal.common.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class SystemConfigService {
    private final SystemConfigRepository repo;
    public SystemConfigService(SystemConfigRepository r) { this.repo = r; }

    @Transactional(readOnly = true)
    public List<ConfigItem> listAll() {
        return repo.findAll().stream()
            .map(c -> new ConfigItem(c.getConfigKey(), c.getConfigValue(), c.getDescription()))
            .toList();
    }

    @Transactional
    public ConfigItem update(String key, String value, Long adminId) {
        var c = repo.findByConfigKey(key)
            .orElseThrow(() -> new ResourceNotFoundException("Config not found"));
        c.setConfigValue(value);
        c.setUpdatedBy(adminId);
        c.setUpdatedAt(Instant.now());
        repo.save(c);
        return new ConfigItem(c.getConfigKey(), c.getConfigValue(), c.getDescription());
    }

    public record ConfigItem(String key, String value, String description) {}
}
