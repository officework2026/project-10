package com.gov.portal.application.dto;

import jakarta.validation.constraints.NotNull;

public record ApplyRequest(@NotNull Long vacancyId, @NotNull Boolean declarationAccepted) {}
