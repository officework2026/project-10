package com.gov.portal.result;

import com.gov.portal.result.dto.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/results")
@PreAuthorize("hasAnyRole('EXAM_COORD','SYS_ADMIN')")
public class AdminResultController {
    private final ResultService resultSvc;
    private final ObjectionService objSvc;

    public AdminResultController(ResultService r, ObjectionService o) {
        this.resultSvc = r; this.objSvc = o;
    }

    @PostMapping("/applications/{applicationId}/marks")
    public ResultResponse marks(@PathVariable Long applicationId, @Valid @RequestBody MarksEntryRequest r) {
        return resultSvc.enterMarks(applicationId, r);
    }

    @PostMapping("/{resultId}/publish")
    public ResultResponse publish(@PathVariable Long resultId) { return resultSvc.publish(resultId); }

    @PostMapping("/notifications/{notificationId}/publish-all")
    public int publishAll(@PathVariable Long notificationId) {
        return resultSvc.publishAll(notificationId);
    }

    @GetMapping
    public Page<ResultResponse> list(@RequestParam(required = false) Long notificationId,
                                     @PageableDefault(size = 20) Pageable p) {
        return resultSvc.list(notificationId, p);
    }

    @GetMapping("/objections")
    public Page<ObjectionResponse> objections(@RequestParam(required = false) String status,
                                              @PageableDefault(size = 20) Pageable p) {
        return objSvc.adminQueue(status, p);
    }

    @PatchMapping("/objections/{id}")
    public ObjectionResponse resolve(@PathVariable Long id, @RequestParam String status,
                                     @RequestParam(required = false) String remarks) {
        return objSvc.resolve(id, status, remarks);
    }
}
