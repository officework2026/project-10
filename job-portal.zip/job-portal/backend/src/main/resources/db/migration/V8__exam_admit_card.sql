CREATE TABLE exam_center (
    id BIGSERIAL PRIMARY KEY,
    notification_id BIGINT NOT NULL REFERENCES recruitment_notification(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    city VARCHAR(100) NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    allocated_count INT NOT NULL DEFAULT 0,
    version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT chk_capacity CHECK (allocated_count <= capacity)
);
CREATE TABLE admit_card (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT UNIQUE NOT NULL REFERENCES application(id),
    roll_number VARCHAR(30) UNIQUE NOT NULL,
    exam_center_id BIGINT NOT NULL REFERENCES exam_center(id),
    exam_date DATE NOT NULL,
    qr_payload TEXT NOT NULL,
    object_key VARCHAR(500),
    generated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE SEQUENCE roll_number_seq START WITH 100000 INCREMENT BY 1;
