CREATE TABLE batch_job (
    id BIGSERIAL PRIMARY KEY,
    job_id VARCHAR(60) NOT NULL UNIQUE,
    state VARCHAR(20) NOT NULL,
    processed INT NOT NULL DEFAULT 0,
    total INT NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    error_message TEXT
);
CREATE INDEX idx_batch_job_job_id ON batch_job(job_id);
