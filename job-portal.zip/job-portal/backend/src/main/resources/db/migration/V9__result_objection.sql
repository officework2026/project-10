CREATE TABLE result (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT UNIQUE NOT NULL REFERENCES application(id),
    marks JSONB NOT NULL,
    total NUMERIC(6,2) NOT NULL,
    qualified BOOLEAN NOT NULL,
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    version BIGINT NOT NULL DEFAULT 0
);
CREATE TABLE objection (
    id BIGSERIAL PRIMARY KEY,
    result_id BIGINT NOT NULL REFERENCES result(id),
    application_id BIGINT NOT NULL REFERENCES application(id),
    question_ref VARCHAR(100) NOT NULL,
    justification TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED',
    admin_remarks TEXT,
    raised_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ
);
