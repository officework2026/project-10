CREATE TABLE system_config (
    id BIGSERIAL PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT NOT NULL,
    description VARCHAR(255),
    updated_by BIGINT REFERENCES users(id),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO system_config (config_key, config_value, description) VALUES
  ('default.fee.general','500.00','Default general fee'),
  ('default.fee.reserved','250.00','Default reserved fee'),
  ('upload.max.size.bytes','5242880','Max upload size'),
  ('objection.window.days','7','Days after result publication'),
  ('session.access.ttl.minutes','15','JWT access TTL');
CREATE TABLE notification_template (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    subject VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    channel VARCHAR(20) NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO notification_template (code, subject, body, channel) VALUES
  ('REGISTRATION','Welcome','Registration successful.','EMAIL'),
  ('APPLICATION_SUBMITTED','Application Received','Your application for {postName} received.','EMAIL'),
  ('PAYMENT_SUCCESS','Payment Confirmed','Payment of {amount} confirmed.','EMAIL'),
  ('ADMIT_CARD_READY','Admit Card','Your admit card for {postName} is ready.','EMAIL'),
  ('RESULT_PUBLISHED','Result Published','Result for {postName} published.','EMAIL');
