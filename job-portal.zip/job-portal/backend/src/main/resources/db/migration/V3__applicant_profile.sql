CREATE TABLE applicant_profile (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    full_name VARCHAR(150) NOT NULL,
    dob DATE NOT NULL,
    category VARCHAR(20),
    gender VARCHAR(10),
    education JSONB NOT NULL DEFAULT '[]'::jsonb,
    experience JSONB DEFAULT '[]'::jsonb,
    address JSONB,
    otr_completed BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
