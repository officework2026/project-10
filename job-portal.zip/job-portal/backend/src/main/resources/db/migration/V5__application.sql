CREATE TABLE application (
    id BIGSERIAL PRIMARY KEY,
    applicant_id BIGINT NOT NULL REFERENCES applicant_profile(id),
    vacancy_id BIGINT NOT NULL REFERENCES vacancy(id),
    status VARCHAR(30) NOT NULL DEFAULT 'SUBMITTED',
    review_remarks TEXT,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT uq_application UNIQUE (applicant_id, vacancy_id)
);
CREATE INDEX idx_app_status ON application(status);
CREATE INDEX idx_app_vacancy ON application(vacancy_id);
CREATE INDEX idx_app_applicant ON application(applicant_id);
