CREATE TABLE recruitment_notification (
    id BIGSERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    department VARCHAR(150) NOT NULL,
    description TEXT,
    open_date DATE NOT NULL,
    close_date DATE NOT NULL,
    stages JSONB,
    fee_general NUMERIC(10,2),
    fee_reserved NUMERIC(10,2),
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    created_by BIGINT REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notif_status ON recruitment_notification(status);
CREATE INDEX idx_notif_close_date ON recruitment_notification(close_date);
CREATE TABLE vacancy (
    id BIGSERIAL PRIMARY KEY,
    notification_id BIGINT NOT NULL REFERENCES recruitment_notification(id) ON DELETE CASCADE,
    post_name VARCHAR(150) NOT NULL,
    total_seats INT NOT NULL CHECK (total_seats > 0),
    reservation JSONB NOT NULL,
    eligibility JSONB NOT NULL
);
CREATE INDEX idx_vacancy_notif ON vacancy(notification_id);
