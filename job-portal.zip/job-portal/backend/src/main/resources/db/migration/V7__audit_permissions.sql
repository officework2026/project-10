-- Append-only on audit_log; applied only when a non-superuser app role exists.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'jobportal') THEN
    EXECUTE 'REVOKE UPDATE, DELETE ON audit_log FROM jobportal';
    EXECUTE 'GRANT INSERT, SELECT ON audit_log TO jobportal';
  END IF;
END $$;
