# Backend — Spring Boot

## Run
```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=dev
```
Health: http://localhost:8080/actuator/health

## Modules
security → auth → user → applicant → recruitment → application → payment →
document → review → exam → result → audit → admin

## Migrations
V1 baseline → V2 refresh_tokens → V3 applicant_profile → V4 recruitment →
V5 application → V6 payment_document → V7 audit_permissions →
V8 exam_admit_card → V9 result_objection → V10 system_config_template →
V11 batch_job

## Java Version
**Java 25 required** (Spring Boot 4.0.x + MapStruct 1.6.3 fails on Java 21).
