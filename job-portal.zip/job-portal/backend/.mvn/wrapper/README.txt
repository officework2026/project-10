Run `mvn wrapper:wrapper` to generate mvnw/mvnw.cmd, or use system `mvn` directly.
